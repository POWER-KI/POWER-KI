/* ======================  ===================================================
		 XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
	 www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***				  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN.Cpp
   Version              :  01
   Date                 :  12/05/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI
   Workpakage           :  GLUE
   Task                 :  SNAP7 - S7 communication
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL to:

		Snap7 Dll ver 1.4.2
		Copyright (C) 2013, 2015 Davide Nardella                                    |
		All rights reserved.
		snap7.sourceForge.net

  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/

#include <windows.h>


using namespace std;

// ==========================================================================================
// PWK WRP
// ==========================================================================================

#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"
#include "snap7.h"

//#pragma optimize( "", off ) //Disable Optimization

// =======================================================================
// Your Define
// =======================================================================

#define CLI_TYP 1
#define SRV_TYP 2
#define PNR_TYP 3

#define GETS7(ptr)\
	 (SNP7*)WRP_PTR(ptr,PTR)

#define CHK_SNP7(t) \
	if(!snp7) WRP_RET_ERR;\
	if(snp7->typ != t) WRP_RET_ERR;

#define RES7 \
if (r != 0)\
	{\
	rs7 = r > 0 ? r * -1 : r;\
	snp7->err = rs7; \
	}\
else rs7 = 1; snp7->err=0;\

#define RES7_CHK \
if (r != 0)\
	{\
	snp7->err = r > 0 ? r * -1 : r; \
	WRP_RET_ERR;\
	}\
else snp7->err=0;\


// =======================================================================
// Your Type Exposed to POWER-KI 
// =======================================================================

DEFINE(struct, Snap7 object)
SNP7	{
	DATA(S7Object,		H7,		"Snap7 Handle");
	DATA(int,			typ,		"1=CLI, 2=SRV, 3=PNR");		
	DATA(int,			err,		"Last Error");		

	DATA(PTR_TO(A_CHR), aIP,		"For auto reconnect");
	DATA(U32,			rack,	"For auto reconnect");		
	DATA(U32,			slot,	"For auto reconnect");		

	DATA(U32,			fcnt,	"1= First connection Ok ");		

	SNP7(int t, int act=0)
		{
		typ=t;
		err=0;
		fcnt=0;

		aIP=NULL;
		rack=0;
		slot=0;	

		switch(t)
			{
			case CLI_TYP:	H7 = Cli_Create();break;
			case SRV_TYP:	H7 = Srv_Create(); break;
			case PNR_TYP:	H7 = Par_Create(act); break;
			}
		}

	D_DESTROYER(SNP7)
		{
		if(aIP) delete aIP;
		}

	};



// =======================================================================
// THE pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, PAY, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *
	// PAY is ANY
	
	if(!PTR) return;

	PTR_TO(SNP7)snp7=(SNP7*)PTR;

	switch(snp7->typ)
		{
		case 1:
			{
			Cli_Disconnect(snp7->H7);
			Cli_Destroy(&snp7->H7);
			}break;

		case 2:
			{
			Srv_Stop(snp7->H7);
			Srv_Destroy(&snp7->H7);
			}break;

		case 3:
			{			
			Par_Destroy(&snp7->H7);
			}break;
		}
	delete snp7;
	}


// =======================================================================
// your code .. 
// =======================================================================
WRP_FUNC(VER, "Return version number" )
	{	
	WRP_DCLBEG;

	WRP_DCLRES(U_STRG, ver,L"Version" );	

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	ver=StrDup(L"1.4.2");

	WRP_RET_OK;
	}

WRP_FUNC(NEW, Create a S7Object Object)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR_DEF(U_STRG, wht, (U_CHR*)L"CLI", "CLI, SRV, PNR");
	WRP_DCLPAR_DEF(int, act, 0, "per PNR active");

	WRP_DCLRES_AS(ptr,L"WRP:EXT");		
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	WRP_SETRES_AS_TYP(ptr, L"WRP:EXT", wht);

	ptr = (ANY) new SNP7(StrSelect(wht, (U_CHR*)L"CLI,SRV,PNR", 0),act);

	WRP_RET_OK;
	}

WRP_FUNC(ErrTxt, Return Error Text)
	{	
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, ptr, "CLI PTR");
	WRP_DCLPAR(int, err,"error code");

	WRP_DCLRES(U_STRG,txt ,"error text");
		
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	char buf[500];	
	PTR_TO(SNP7)snp7 = GETS7(ptr);
	if (!snp7) WRP_RET_ERR;

	if (err > 0)
		{
		txt=StrDup((U_CHR*)L"OK");
		WRP_RET_OK;
		}

	if (err == 0)
		{
		txt=StrDup((U_CHR*)L"ERROR in Parameter or in Connection");
		WRP_RET_OK;
		}

	err *=-1; //POWER-KI use negative for error

	switch(snp7->typ)
		{
		case 1:	r = Cli_ErrorText(err, buf, 499);break;
		case 2:	r = Srv_ErrorText(err, buf, 499); break;
		case 3:	r = Par_ErrorText(err, buf, 499); break;

		default: WRP_RET_ERR;
		}
	
	r=Par_ErrorText(err, buf, 499);

	txt=StrAtoU(buf);
		
	WRP_RET_OK;
	}


WRP_FUNC(SetPar, Set Parameter)
	{	
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, ptr, "CLI PTR");
	WRP_DCLPAR(U_STRG, par,"Parameter name");
	WRP_DCLPAR(U32, val, "Parameter value");
			
	WRP_DCLRES(int, rs7, Result);
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	int pn;
	int pt;

	PTR_TO(SNP7)snp7 = GETS7(ptr);
	if (!snp7) WRP_RET_ERR;

	pn = StrSelect(par,(U_CHR*) L"LocPort, RmtPort, PingTmo, SndTmo, RcvTmo, WorkInterval, SrcRef, DstRef, PDUrqs, MaxCli, BsndTmo, BrcvTmo, RecoveryTime, KeepAliveTime", true);

	if(snp7->typ==CLI_TYP && (pn==1 || pn==6 || pn>10 ))
		{
		pn=0;
		}

	if(snp7->typ==SRV_TYP && (pn!=1 && pn!=6 && pn!=10 && pn!=11 ))
		{
		pn=0;
		}

	if(snp7->typ==PNR_TYP && (pn==1 || pn==11 ))
		{
		pn=0;
		}

	if(pn == 0) WRP_RET_ERR;

	switch (snp7->typ)
		{
		case 1:	r = Cli_SetParam(snp7->H7, pn, &val); break;
		case 2:	r = Srv_SetParam(snp7->H7, pn, &val); break;
		case 3:	r = Par_SetParam(snp7->H7, pn, &val); break;

		default: WRP_RET_ERR;
		}

	RES7;
		
	WRP_RET_OK;
	}


WRP_FUNC(GetPar, Get Parameter)
	{	
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, ptr, "CLI PTR");
	WRP_DCLPAR(U_STRG, par,"Parameter name");

	WRP_DCLRES(U32, val, "Parameter value");			
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	int pn;
	int pt;

	PTR_TO(SNP7)snp7 = GETS7(ptr);
	if (!snp7) WRP_RET_ERR;

	pn = StrSelect(par,(U_CHR*) L"LocPort, RmtPort, PingTmo, SndTmo, RcvTmo, WorkInterval, SrcRef, DstRef, PDUrqs, MaxCli, BsndTmo, BrcvTmo, RecoveryTime, KeepAliveTime", true);

	if(snp7->typ==CLI_TYP && (pn==1 || pn==6 || pn>10 ))
		{
		pn=0;
		}

	if(snp7->typ==SRV_TYP && (pn!=1 && pn!=6 && pn!=10 && pn!=11 ))
		{
		pn=0;
		}

	if(snp7->typ==PNR_TYP && (pn==1 || pn==11 ))
		{
		pn=0;
		}

	if(pn == 0) WRP_RET_ERR;

	switch (snp7->typ)
		{
		case 1:	r = Cli_GetParam(snp7->H7, pn, &val); break;
		case 2:	r = Srv_GetParam(snp7->H7, pn, &val); break;
		case 3:	r = Par_GetParam(snp7->H7, pn, &val); break;

		default: WRP_RET_ERR;
		}

	if(r != 0) WRP_RET_ERR;
		
	WRP_RET_OK;
	}


//------------------------------------------------------
// CLI Operations
//------------------------------------------------------

WRP_FUNC(ConTyp, Set Connection Type)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "CLI PTR");
	WRP_DCLPAR(U_STRG, typ, "PG, OP, S7bas");
	WRP_DCLPAR_DEF(U32, bas, 0x01, "for S7Basic fro 0x03-to-0x10");

	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	int t;

	PTR_TO(SNP7)snp7= GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	switch(StrSelect(typ,(U_CHR*)L"PG,OP",0))
		{
		case 1:	t=0x01; break;
		case 2:	t=0x02; break;
		default:	t=bas;	
		}
	
	if(t<0 || t >0x10) WRP_RET_ERR;

	WRP_PTR_LCKS(ptr);
	r=Cli_SetConnectionType(snp7->H7,t);
	WRP_PTR_LCKR(ptr);

	RES7;

	WRP_RET_OK;
	}

WRP_FUNC(ConPar, Set Connection Parameters)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "CLI PTR");
	WRP_DCLPAR(U_STRG, IP, "IP Address");
	WRP_DCLPAR(U32, LTSAP, "Local TSAP (PC)");
	WRP_DCLPAR(U32, RTSAP, "Remote TSAP (PLC)");

	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	PTR_TO(A_CHR) aIP=StrUtoA(IP);

	PTR_TO(SNP7)snp7= GETS7(ptr);
	CHK_SNP7(CLI_TYP);
		
	WRP_PTR_LCKS(ptr);
	r=Cli_SetConnectionParams(snp7->H7,aIP,LTSAP,RTSAP);
	WRP_PTR_LCKR(ptr);

	if(aIP) delete aIP;

	RES7;

	WRP_RET_OK;
	}


FUNCTION(int, Auto reconnect)
Reconnect(PTR_TO(SNP7)snp7)
	{
	int r;
	if (!snp7->aIP)
		{
		r= Cli_Connect(snp7->H7);
		}
	else {
		r= Cli_ConnectTo(snp7->H7, snp7->aIP, snp7->rack, snp7->slot);
		}

	if (r == 0)snp7->fcnt = 1;

	return r;
	}

WRP_FUNC(Connect, Connect )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "CLI PTR");
	WRP_DCLPAR_DEF(U_STRG, IP, NULL, "IP Address");
	WRP_DCLPAR_DEF(U32, RACK, 0, "PLC Rack number");
	WRP_DCLPAR_DEF(U32, SLOT, 0,"PLC Slot number");

	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	PTR_TO(SNP7)snp7 = GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	if (IP)
		{
		if (snp7->aIP)
			{
			delete snp7->aIP;
			snp7->aIP = NULL;
			}

		snp7->aIP = StrUtoA(IP);

		snp7->rack = RACK;
		snp7->slot = SLOT;
		}

	WRP_PTR_LCKS(ptr);
	r=Reconnect(snp7);
	WRP_PTR_LCKR(ptr);

	RES7;
	
	WRP_RET_OK;
	}

WRP_FUNC(End, DisConnect)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "CLI PTR");

	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;

	PTR_TO(SNP7)snp7= GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	WRP_PTR_LCKS(ptr);
	r=Cli_Disconnect(snp7->H7);
	WRP_PTR_LCKR(ptr);
	
	if (r == 0)snp7->fcnt = 0;

	RES7;

	WRP_RET_OK;
	}


WRP_FUNC(Read, Read Area )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "CLI PTR");
	WRP_DCLPAR(U_STRG, area, "INP, OUT, MRK, DB, CNT, TMR");	
	WRP_DCLPAR_DEF(U32, db, 0, "data block num");
	WRP_DCLPAR(U_STRG, wsz, "word size");
	WRP_DCLPAR_DEF(U32, adr, 0, "Offset to start");
	WRP_DCLPAR(U32, wnm, "word to read");
	WRP_DCLPAR(ANY, buf, "buffer");
	WRP_DCLPAR_DEF(U32, bufOff, 0, "buffer");
	WRP_DCLPAR_DEF(U_STRG, swp, NULL,"swap: �WORD, �DWORD");
	
	WRP_DCLRES(int, rs7, Result);
	
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
		
	int c_wsz;//code;
	int n_wsz;//size in byte;

	PTR_TO(SNP7)snp7 = GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	buf=WRP_PTR(buf, PTR);
	rs7=0;

	if(bufOff)
		{
		bufOff--;	 
		buf= & ((U8*)buf)[bufOff];
		}

	switch (StrSelect(wsz, (U_CHR*)L"BIT, BYTE, WORD, DWORD, REAL, COUNTER, TIMER", true))
		{
		case 0:	WRP_RET_ERR;
 
		case 1:
			{
			n_wsz = 1;
			c_wsz=0x01;
			}break;

		case 2:
			{
			n_wsz = 1;
			c_wsz = 0x02;
			}break;

		case 3:
			{
			n_wsz = 2;
			c_wsz = 0x04;
			}break;

		case 4:
			{
			n_wsz = 4;
			c_wsz = 0x06;
			}break;

		case 5:
			{
			n_wsz = 4;
			c_wsz = 0x08;
			}break;

		case 6:
			{
			n_wsz = 2;
			c_wsz = 0x1C;
			}break;

		case 7:
			{
			n_wsz = 2;
			c_wsz = 0x1D;
			}break;
		}

	int n_area;
	switch(StrSelect(area,(U_CHR*)L"INP, OUT, MRK, DB, CNT, TMR", true))
		{
		case 0:	WRP_RET_ERR;
 
		case 1:
			{
			n_area=0x81;
			}break;

		case 2:
			{
			n_area=0x82;
			}break;

		case 3:
			{
			n_area=0x83;
			}break;

		case 4:
			{
			n_area=0x84;
			}break;

		case 5:
			{
			n_area=0x1C;
			n_wsz = 2;
			c_wsz = 0x1C;
			}break;

		case 6:
			{
			n_area=0x1D;
			n_wsz = 2;
			c_wsz = 0x1D;
			}break;
		}


	//-----------------------
	int ntry = 0;
	int tswp = 0;
	PTR_TO(U8) Tb = NULL;
	int tsz =0;

	WRP_PTR_LCKS(ptr);

	if (!snp7->fcnt)
		{
		r = Reconnect(snp7);
		if(r!=0) goto RET;
		}

	tsz = n_wsz * wnm;
	tswp= StrSelect(swp, (U_CHR*)L"BYTE,WORD,DWORD");	
	
	Tb= new U8[tsz];
	
	LOP:
	
	r = Cli_ReadArea(snp7->H7, n_area, db, adr, wnm, c_wsz, Tb);	

	if (r != 0 && ntry == 0)
		{
		ntry=1;
		r=Reconnect(snp7);
		if(r==0) goto LOP;
		}

	RET:
	WRP_PTR_LCKR(ptr);
	
	if(r==0)
		{
		switch(tswp)
			{
			case 1: SWAPBUF8(Tb, tsz); break;
			case 2: SWAPBUF16(AS_PTR_TO(U16)Tb, tsz / 2); break;
			case 3: SWAPBUF32(AS_PTR_TO(U32)Tb, tsz / 4); break;
			}

		memcpy(buf,Tb,tsz);
		}

	if(Tb) delete Tb;

	RES7;

	WRP_RET_OK;
	}

WRP_FUNC(Write, Write Area )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "CLI PTR");
	WRP_DCLPAR(U_STRG, area, "INP, OUT, MRK, DB, CNT, TMR");	
	WRP_DCLPAR_DEF(U32, db, 0, "data block num");
	WRP_DCLPAR(U_STRG, wsz, "word size");
	WRP_DCLPAR_DEF(U32, adr, 0, "Offset to start");
	WRP_DCLPAR(U32, wnm, "word to write");	
	WRP_DCLPAR(ANY, buf, "buffer");
	WRP_DCLPAR_DEF(U32, bufOff, 0, "buffer");
	WRP_DCLPAR_DEF(U_STRG, swp, NULL, "swap: �WORD, �DWORD");
		
	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	
	int c_wsz;//code;
	int n_wsz;//size in byte;

	PTR_TO(SNP7)snp7 = GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	buf = WRP_PTR(buf, PTR);
	rs7 = 0;

	if(bufOff)
		{
		bufOff--;	 
		buf= & ((U8*)buf)[bufOff];
		}

	switch (StrSelect(wsz, (U_CHR*)L"BIT, BYTE, WORD, DWORD, REAL, COUNTER, TIMER", true))
		{
		case 0:	WRP_RET_ERR;
 
		case 1:
			{
			n_wsz = 1;
			c_wsz=0x01;
			}break;

		case 2:
			{
			n_wsz = 1;
			c_wsz = 0x02;
			}break;

		case 3:
			{
			n_wsz = 2;
			c_wsz = 0x04;
			}break;

		case 4:
			{
			n_wsz = 4;
			c_wsz = 0x06;
			}break;

		case 5:
			{
			n_wsz = 4;
			c_wsz = 0x08;
			}break;

		case 6:
			{
			n_wsz = 2;
			c_wsz = 0x1C;
			}break;

		case 7:
			{
			n_wsz = 2;
			c_wsz = 0x1D;
			}break;
		}

	int n_area;
	switch(StrSelect(area,(U_CHR*)L"INP, OUT, MRK, DB, CNT, TMR", true))
		{
		case 0:	WRP_RET_ERR;
 
		case 1:
			{
			n_area=0x81;
			}break;

		case 2:
			{
			n_area=0x82;
			}break;

		case 3:
			{
			n_area=0x83;
			}break;

		case 4:
			{
			n_area=0x84;
			}break;

		case 5:
			{
			n_area=0x1C;
			n_wsz = 2;
			c_wsz = 0x1C;
			}break;

		case 6:
			{
			n_area=0x1D;
			n_wsz = 2;
			c_wsz = 0x1D;
			}break;
		}

	//-----------------------	
	int ntry = 0;
	int tswp = 0;
	PTR_TO(U8) Tb = NULL;
	int tsz = 0;

	WRP_PTR_LCKS(ptr);

	if (!snp7->fcnt)
		{
		r = Reconnect(snp7);
		if(r!=0) goto RET;
		}

	tsz = n_wsz * wnm;
	tswp= StrSelect(swp, (U_CHR*)L"BYTE,WORD,DWORD");	
	
	if (tswp)
		{
		Tb= new U8[tsz];
		memcpy(Tb, buf, tsz);

		switch (tswp)
			{
			case 1: SWAPBUF8(Tb, tsz); break;
			case 2: SWAPBUF16(AS_PTR_TO(U16)Tb, tsz / 2); break;
			case 3: SWAPBUF32(AS_PTR_TO(U32)Tb, tsz / 4); break;
			}
		}
	else {
		Tb=(U8*)buf;
		}
	
	LOP:
	
	r=Cli_WriteArea(snp7->H7, n_area, db, adr, wnm, c_wsz, Tb);

	if (r != 0 && ntry == 0)
		{
		ntry=1;
		r=Reconnect(snp7);
		if(r==0) goto LOP;
		}
	
	RET:
	WRP_PTR_LCKR(ptr);

	if(tswp)delete Tb;
		
	RES7;

	WRP_RET_OK;
	}

//------------------------------------------------------
// CLI Directory Functions
//------------------------------------------------------

WRP_FUNC(LisBlk, List Blocs or List Block of Type)
	{	
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, ptr, "CLI PTR");	

	WRP_DCLRES(U_STRG, tbl, "formatted text of lis block");
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;	
	
	PTR_TO(SNP7)snp7 = GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	TS7BlocksList buf;

	r = Cli_ListBlocks(snp7->H7, &buf);
	RES7_CHK;

	tbl= new U_CHR[200];

	StrFormat(tbl,200, (U_CHR*) L"OB;%d\r\nFB;%d\r\nFC;%d\r\nSFB;%d\r\nDB;%d\r\nSDB;%d",
		buf.OBCount, buf.FBCount, buf.FCCount, buf.SFBCount, buf.DBCount, buf.SDBCount );
	
	WRP_RET_OK;
	}


WRP_FUNC(LisBlkTyp, List Block of Type)
	{	
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, ptr, "CLI PTR");
	WRP_DCLPAR_DEF(U_STRG, bty, NULL, "DB, SDB, FC, SFC, FB, SFB, OB");

	WRP_DCLRES_AS(buf,L"BUF:BUF");
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	int n_bty;
	
	PTR_TO(SNP7)snp7 = GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	if(!bty) WRP_RET_OK;

	n_bty=StrSelect(bty,(U_CHR*)L"DB, SDB, FC, SFC, FB, SFB, OB");
	if(!n_bty)WRP_RET_ERR;

	if(n_bty==7) n_bty=0x38;
	else n_bty+=0x40;

	PTR_TO(TS7BlocksOfType) blk = (TS7BlocksOfType*) new word[0x2000];
	int nblk = 0x2000;

	r=Cli_ListBlocksOfType(snp7->H7, n_bty, blk, &nblk);	
	RES7_CHK;	

	WRP_SETRES_AS_PAY(buf, L"BUF:BUF",nblk*2);

	WRP_RET_OK;
	}

WRP_FUNC(AgBlkInf, Get AG block info)
	{	
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, ptr, "CLI PTR");	
	WRP_DCLPAR_DEF(U_STRG, bty, NULL, "DB, SDB, FC, SFC, FB, SFB, OB");
	WRP_DCLPAR(U32, bkn, "Block number");

	WRP_DCLRES(U_STRG, tbl, "formatted text of info");
	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;	
	int n_bty;

	PTR_TO(SNP7)snp7 = GETS7(ptr);
	CHK_SNP7(CLI_TYP);

	if (!bty) WRP_RET_OK;

	n_bty = StrSelect(bty, (U_CHR*)L"DB, SDB, FC, SFC, FB, SFB, OB");
	if (!n_bty)WRP_RET_ERR;

	if (n_bty == 7) n_bty = 0x38;
	else n_bty += 0x40;

	TS7BlockInfo buf;

	r = Cli_GetAgBlockInfo(snp7->H7, n_bty, bkn, &buf);
	RES7_CHK;

	tbl= new U_CHR[400];
	const U_CHR* lngTbl[]={{L"AWL"},{L"KOP"},{L"FUP"},{L"SCL"},{L"DB"},{L"GRAPH"}};

	StrFormat(tbl,400, (U_CHR*) 
		L"BlkType;%d\r\nBlkNumber;%s\r\nBlkLang;%d\r\nBlkFlags;%d\r\nMC7Size;%d\r\nLoadSize;%d\r\n"
		L"LocalData;%d\r\nSBBLength;%s\r\nCheckSum;%d\r\nVersion;%d\r\n"
		L"CodeDate;%s\r\nIntfDate;%s\r\nAuthor;%s\r\nFamily;%s\r\nHeader;%s",

		buf.BlkType, buf.BlkNumber, lngTbl[buf.BlkLang], buf.BlkFlags, buf.MC7Size, buf.LoadSize,
		 buf.LocalData, buf.SBBLength, buf.CheckSum, buf.Version,
		 buf.CodeDate, buf.IntfDate, buf.Author, buf.Family, buf.Header
		);
	
	WRP_RET_OK;
	}

//------------------------------------------------------
// SRV Operations
//------------------------------------------------------

WRP_FUNC(Start, Server Start )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "SRV PTR");
	WRP_DCLPAR_DEF(U_STRG, IP, NULL, "IP Address");

	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	PTR_TO(SNP7)snp7= GETS7(ptr);
	CHK_SNP7(SRV_TYP);

	if (!IP)
		{
		r = Srv_Start(snp7->H7);
		}
	else {
		PTR_TO(A_CHR) aIP=StrUtoA(IP);	
		
		r=Srv_StartTo(snp7->H7, aIP);

		if (aIP) delete aIP;
		}

	RES7;

	WRP_RET_OK;
	}

WRP_FUNC(Stop, Server Stop )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "SRV PTR");	

	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	PTR_TO(SNP7)snp7= GETS7(ptr);

	r = Srv_Stop(snp7->H7);

	RES7;

	WRP_RET_OK;
	}

WRP_FUNC(Area, Operation upon area )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(ANY,ptr, "SRV PTR");
	WRP_DCLPAR(U_STRG, wht, "ADD, RMV, LCKS, LCKR");
	WRP_DCLPAR(U_STRG, area, "INP, OUT, MRK, DB, CNT, TMR");			
	WRP_DCLPAR_DEF(U32, db, 0, "data block num");
	WRP_DCLPAR(ANY, buf, "buffer");
	WRP_DCLPAR_DEF(U32, bsz, 0, "buffer size");	
		
	WRP_DCLRES(int, rs7, Result);

	WRP_DCLEND;
		
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	int r;
	int n_area;
	unsigned ibsz;

	PTR_TO(SNP7)snp7= GETS7(ptr);
	CHK_SNP7(SRV_TYP);

	n_area = StrSelect(area, (U_CHR*)L"INP, OUT, MRK, TMR, CNT, DB", true);
	if (!n_area)  WRP_RET_ERR;
	n_area--;

	switch(StrSelect(wht, (U_CHR*)L"ADD,RMV,LCKS,LCKR",0))
		{
		case 1:
			{
			buf= WRP_PTR(buf, PTR);
			//ibsz=(unsigned) WRP_PTR(buf, PAY);
			//bsz= bsz <=0 | bsz >ibsz ? ibsz: bsz;
			r=Srv_RegisterArea(snp7->H7,n_area,db,buf,bsz);
			}break;
	
		case 2:
			{
			r=Srv_UnregisterArea(snp7->H7,n_area,db);		
			}break;
		
		case 3:
			{
			r=Srv_LockArea(snp7->H7,n_area,db);		
			}break;

		case 4:
			{
			r=Srv_UnlockArea(snp7->H7,n_area,db);		
			}break;

		default: 	WRP_RET_ERR;
		}

	RES7;
	WRP_RET_OK;
	}

// ==========================================================================================
// Remember to add your function (comma separated list of function name)
// ==========================================================================================

WRP_INIT( VER,	NEW, SetPar, GetPar, ErrTxt, ConTyp, ConPar, Connect, End, Read, Write, 
		LisBlk, LisBlkTyp, AgBlkInf, 
		Start, Stop, Area);

//#pragma optimize( "", on )
// ==========================================================================================



