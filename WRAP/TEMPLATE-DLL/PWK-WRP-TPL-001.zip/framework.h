// header.h: file di inclusione per file di inclusione di sistema standard
// o file di inclusione specifici del progetto
//

#pragma once

#define WIN32_LEAN_AND_MEAN             // Escludere gli elementi usati raramente dalle intestazioni di Windows
// File di intestazione di Windows
#include <windows.h>
