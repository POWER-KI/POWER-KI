/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                      Tel/Fax +39 030 2350035
    *** RESERVED ***					(C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-CORE.hpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   Core implementation for user Wrap DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------

  USE :
  ---------------------------------------------------------------------------
  Include this file in your  "Wrap" 

  the wrap function shoud be like:
	
	WRP_FUNC(SUM,Perform a sum)	
		{
		WRP_BEGINIT;

		DCL_WRPPAR(int, a);		//declare an input par
		DCL_WRPPAR(int, b);

		DCL_WRPRES(int, c);		//declare the return value if any

		WRP_ENDINIT;					

		//-----------------------------	
		//now your code !! never before
		//-----------------------------

		c=a+b;

		return 1;				// 1=ok  0 or less Error (in POWER-KI -> NULL)
		}
	
  Remember to list your function :

	WRP_INIT(Circle,Sum);
	

  Parameter Type:

	I8, U8, I16, U16, I32 int, U32 unsigned, I64, U64, F32 float, F64 double, U_CHR, ANY 

  To declare a PWK PTR res type use:

	DCL_WRPRES_AS(typ,nam,as)

  Where "as": 

		IS:		LIB:TAG:TYP:PAY

	 For BUF:		LIB -> BUF 
		and:		TAG -> BUF, CHK		
		and:		TYP -> see above
		and:		PAY -> size in byte
				
	 For MAT:		LIB -> OCV 
		and:		TAG -> MAT		
	 (OpenCv)

		IS:		typ -> (user typ to return in WRP_DEL(ptr,typ) )	
  ---------------------------------------------------------------------------
*/

#include "PWK-WRP-STILE.hpp"
#include "PWK-WRP-LISTE.hpp"

#ifndef WRP_EXPORTS
	#define WRP_EXPORTS __declspec(dllexport)
#endif

typedef char		A_CHR;
typedef wchar_t	U_CHR;

typedef WRP_EXPORTS int(* WRPPWK_EXC)(ANY parBuf);

#pragma pack(1)
DEFINE(struct,WRP_PAR)
WRP_PAR
	{
	DATA(PTR_TO(U_CHR),			par,			Par name);
	DATA(int,					off,			offset);
	DATA(int,					siz,			size in byte);
	DATA(PTR_TO(U_CHR),			typ,			Type: U8 I8 I16 U16 I32 U32 I64 U64 F32 F64 PTR   );
	DATA(PTR_TO(U_CHR),			as,			AS: LIB:TAG:TYP:PAY);
	};

DEFINE(struct, WRP_FNC)
WRP_FNC
	{
	DATA(PTR_TO(U_CHR),			fnc,			function name);
	DATA(WRPPWK_EXC,			ptr,			Function Pointer);	
	DATA(int,					np,			Number of parameter);
	DATA(PTR_TO(WRP_PAR),		par,			Ptr to input par);	
	DATA(int,					psz,			Size in byte of par buffer);	
	DATA(int,					nr,			Number of res 0=no res);	
	DATA(PTR_TO(WRP_PAR),		res,			Ptr to return par - only one);
	DATA(int,					rsz,			Size in byte of res buffer);	
	};

DEFINE(struct, WRP_TBL)
WRP_TBL
	{
	DATA(int,					nf,			Number of function);
	DATA(PTR_TO(WRP_FNC),		pf,			Ptr to function);
	};

#pragma pack()

/*---------------------------------------------
#define __STR2WSTR(str) L##str
#define _STR2WSTR(str) __STR2WSTR(str)
#define __FUNCTIONW__ _STR2WSTR(__FUNCTION__)
//---------------------------------------------
*/

typedef WRP_EXPORTS PTR_TO(WRP_TBL)(CALLBACK* WRPPWK_GETTBL)();
typedef WRP_EXPORTS NONE(CALLBACK* WRPPWK_PTRDEL)(ANY);

PTR_TO(WRP_TBL) wrpTbl=NULL;

// =======================================================================

DEFINE(struct, Function poiter container)
lisParElm: public DNODO
	{
	WRP_PAR p;
	};

LIST_OBJ_MNG<lisParElm> lisPar;
LIST_OBJ_MNG<lisParElm> lisRes;

FUNCTION(NONE, Register Parameter)
PWK_WRP_PAR_REG(PTR_TO(U_CHR)id, PTR_TO(U_CHR)typ, int szt)
	{
	PTR_TO(lisParElm) pe=new lisParElm;
	pe->p.par=id;
	pe->p.typ=typ;
	pe->p.siz=szt;
	lisPar.Add(pe);
	}

FUNCTION(NONE, Register Return res)
PWK_WRP_RES_REG(PTR_TO(U_CHR)id, PTR_TO(U_CHR)typ, int szt, PTR_TO(U_CHR)as=NULL)
	{
	PTR_TO(lisParElm) pe=new lisParElm;
	pe->p.par=id;
	pe->p.typ=typ;
	pe->p.siz=szt;
	pe->p.as=as;
	lisRes.Add(pe);
	}


FUNCTION(NONE, Set Func Par)
PWK_WRP_PAR_SET(int idx)
	{
	PTR_TO(WRP_PAR)par;
	PTR_TO(lisParElm) pe;
	int i, in;
	int szt=0;
	int off=0;

	in=wrpTbl->pf[idx].np= lisPar.GetNum();

	if(!in)
		{
		wrpTbl->pf[idx].par = NULL;		
		wrpTbl->pf[idx].psz = 0;				
		}
	else {	
		par=wrpTbl->pf[idx].par = new WRP_PAR[in];
	
		for(i=0; i<in; i++)
			{
			pe=lisPar.Get();
			par[i].off=off;
			par[i].par=pe->p.par;
			par[i].siz=pe->p.siz;
			par[i].typ = pe->p.typ;
			off+= par->siz;
			delete pe;
			}	
		wrpTbl->pf[idx].psz=off;
		lisPar.Clean();
		}

	in=wrpTbl->pf[idx].nr= lisRes.GetNum();

	if(!in)
		{
		wrpTbl->pf[idx].res = NULL;		
		wrpTbl->pf[idx].rsz = 0;
		}
	else {	
		par=wrpTbl->pf[idx].res = new WRP_PAR[in];
	
		for(i=0; i<in; i++)
			{
			pe=lisRes.Get();
			par[i].off=off;
			par[i].par=pe->p.par;
			par[i].siz=pe->p.siz;
			par[i].typ = pe->p.typ;
			par[i].as = pe->p.as;
			off+= par->siz;
			delete pe;
			}	
		wrpTbl->pf[idx].rsz=off;
		lisRes.Clean();
		}


	}

FUNCTION(NONE, Add function to init)
PWK_WRP_Init(WRPPWK_EXC fnc, ...)
	{
	int cnt=0;
	WRPPWK_EXC fbeg;
	
	va_list v1;
	va_list v2;
	
	va_start(v1,fnc);
	va_copy(v2,v1);
	fbeg=fnc;	
	while(fnc!=NULL)
		{
		cnt++;
		fnc=va_arg(v1, WRPPWK_EXC);
		}
	va_end(v1);

	wrpTbl = new WRP_TBL;

	wrpTbl->nf = cnt;
	wrpTbl->pf = new WRP_FNC[cnt];

	fnc=fbeg;	
	cnt=0;
	while(fnc!=NULL)
		{
		wrpTbl->pf[cnt].ptr = fnc;
		(fnc)((ANY)cnt);
		PWK_WRP_PAR_SET(cnt);

		cnt++;
		fnc=va_arg(v2, WRPPWK_EXC);
		}
	va_end(v2);
	}

//------------------------------------------------------

#define DCL_WRPPAR(typ,nam) \
	typ nam; \
	if(unsigned(parbuf)< 1000)\
		{\
		nam=NULL;\
		PWK_WRP_PAR_REG((U_CHR*)L#nam, (U_CHR*)L#typ, sizeof(typ));\
		}\
	else {\
		nam= *(typ*)WRP_GETPAR((U_CHR*)L#nam, parbuf, sizeof(typ),(U_CHR*) __FUNCTIONW__);\
		}


#define	WRP_BEGINIT \
		if(unsigned(parbuf)<1000) wrpTbl->pf[unsigned(parbuf)].fnc=(U_CHR*)__FUNCTIONW__;

#define WRP_ENDINIT	if(unsigned(parbuf)<1000) return 1;

//------------------------------------------------------

#define DCL_WRPRES(typ,nam) \
	typ &nam= *(typ*) WRP_GETRET((U_CHR*)L#nam, parbuf, sizeof(typ),(U_CHR*) L#typ,(U_CHR*) __FUNCTIONW__);

#define DCL_WRPRES_AS(typ,nam,as) \
	typ &nam= *(typ*) WRP_GETRET((U_CHR*)L#nam, parbuf, sizeof(typ), (U_CHR*)L#typ,(U_CHR*) __FUNCTIONW__, as);


ANY WRP_GETRET(PTR_TO(U_CHR)id, ANY buf, int szt, PTR_TO(U_CHR) typ, const PTR_TO(U_CHR) fun, PTR_TO(U_CHR)as=NULL)
	{
	if (unsigned(buf)< 1000)
		{	
		PWK_WRP_RES_REG(id, typ, szt, as); 
		return buf;
		}
	
	int i,in, y, yn;
	PTR_TO(WRP_PAR)par;

	in= wrpTbl->nf;

	for(i=0; i<in; i++)
		{
		if(!_wcsicmp(fun,wrpTbl->pf[i].fnc))
			{
			par = wrpTbl->pf[i].res;
			yn= wrpTbl->pf[i].nr;

			for(y=0; y<yn; y++)
				{
				if(!_wcsicmp(id, par[y].par))
					{
					par[y].as=as;
					return &((U8*)buf)[par[y].off];
					}
				}			
			}
		}
	return NULL;
	}

//------------------------------------------------------

ANY WRP_GETPAR(PTR_TO(U_CHR)id, ANY buf, int szt, const PTR_TO(U_CHR) fun)
	{
	int i,in, y, yn;
	PTR_TO(WRP_PAR)par;

	in= wrpTbl->nf;

	for(i=0; i<in; i++)
		{
		if(!_wcsicmp(fun,wrpTbl->pf[i].fnc))
			{
			par = wrpTbl->pf[i].par;
			yn= wrpTbl->pf[i].np;

			for(y=0; y<yn; y++)
				{
				if(!_wcsicmp(id, par[y].par))
					{
					return &((U8*)buf)[par[y].off];
					}
				}			
			}
		}

	return NULL;
	}

// -----------------------------------------------------------------------
#define WRP_DEL(PTR,TYP,cmnt)\
FUNCTION(extern "C" WRP_EXPORTS NONE, Delete User created pointer) \
PWK_PTRDEL(ANY PTR, PTR_TO(U_CHR) typ)

// -----------------------------------------------------------------------
#define WRP_FUNC(nam,cmnt) \
	WRP_EXPORTS int nam (ANY parbuf)	

// -----------------------------------------------------------------------

#define WRP_INIT(...) \
extern "C" \
WRP_EXPORTS PTR_TO(WRP_TBL)PWK_GETTBL() \
	{ \
	if(!wrpTbl)\
		{\
		PWK_WRP_Init(__VA_ARGS__,NULL);\
		}\
	return wrpTbl;\
	}

// =======================================================================
// PWK WRP - END
// =======================================================================





