/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                      Tel/Fax +39 030 2350035
    *** RESERVED ***					(C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-00.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/

#include <windows.h>


// =======================================================================
// PWK WRP
// =======================================================================
// Parameter Type: I8, U8, I16, U16, I32 int, U32 unsigned, I64, U64, F32 float, F64 double, U_CHR, ANY

#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

WRP_DEL(PTR, TYP, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *

	/* Example:
	if(!_wcsicmp(TYP,L"myObjId"))
		{
		delete (myObjPtr*) PTR;
		return;
		}
	*/
	
	;
	}

// =======================================================================
// your code .. 
// =======================================================================

WRP_FUNC(Example, Perform a sum)
	{
	WRP_BEGINIT;

	DCL_WRPPAR(int, a);		//declare an input par
	DCL_WRPPAR(int, b);

	DCL_WRPRES(int, c);		//declare the return value if any

	WRP_ENDINIT;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	c = a + b;

	return 1;				// 1=ok  0 or less Error (in POWER-KI -> NULL)
	}


// Remeber to add your function (comma separated list of function name)
WRP_INIT(Example);


/*
// =======================================================================
// PWK WRP example
// =======================================================================
  The wrap function shoud be like:
	
	WRP_FUNC(SUM,Perform a sum)	
		{
		WRP_BEGINIT;

		DCL_WRPPAR(int, a);		//declare an input par
		DCL_WRPPAR(int, b);

		DCL_WRPRES(int, c);		//declare the return value if any

		WRP_ENDINIT;					

		//-----------------------------	
		//now your code !! never before
		//-----------------------------

		c=a+b;

		return 1;				// 1=ok  0 or less Error (in POWER-KI -> NULL)
		}
	
  Remember to list your function in :

	WRP_INIT(Circle,Sum);
	
  Parameter Type:

	I8, U8, I16, U16, I32 int, U32 unsigned, I64, U64, F32 float, F64 double, U_CHR, ANY 

  To declare a PWK PTR res type use:

	DCL_WRPRES_AS(typ,nam,as)

  Where "as": 

		IS:		LIB:TAG:TYP:PAY

	 For BUF:		LIB -> BUF 
		and:		TAG -> BUF, CHK		
		and:		TYP -> see above
		and:		PAY -> size in byte
				
	 For MAT:		LIB -> OCV 
		and:		TAG -> MAT		
	 (OpenCv)

		IS:		typ -> (user typ to return in WRP_DEL(ptr,typ) )	
---------------------------------------------------------------------------
<EOF>*/


