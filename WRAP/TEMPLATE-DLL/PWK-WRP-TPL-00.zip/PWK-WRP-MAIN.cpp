/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***					  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/

#include <windows.h>

using namespace std;

// ==========================================================================================
// PWK WRP
// ==========================================================================================
/* Parameter Type:	I8, U8, I16, U16, I32 int, U32 unsigned, I64, U64, 
				F32 float, F64 double, U_STRG U_CHR*, ANY

   KeyWORD:		WRP_DCLBEG;	  				//Section Begin
	
				WRP_DCLPAR(typ, parName, Comment);	
				WRP_DCLPAR_DEF(typ, parName, defValue, Comment);

				WRP_DCLRES(typ, resName, Comment);							//Return Value (Only The Fst is returned)
				WRP_DCLRES_AS(typ, resName, stringAs, Comment);
				WRP_DCLRES_AS_WPAY(typ,resName, stringAs, payload, Comment); //If it has a variable payLoad like buffer size

				WRP_DCLEND;					//Section End

				WRP_TRIGSYNC;				// Trigger call
				WRP_TRIGPARL;
				WRP_TRIGSYNC_With( par/resName enum);
				WRP_TRIGPARL_With( par/resName enum);

				WRP_TRIG_LCKS;				// Lock Set the Trig semaphore 
				WRP_TRIG_LCKR;				// Lock Reset the Trig semaphore 

				WRP_INIT(FuncName );		//comma separated list of function

   stringAs:		LIB:TAG:TYP:PAY

				example	BUF:BUF:U8:10	//Buffer with fix value or WRP_DCLRES_AS_WPAY(ANY,buf, "BUF:BUF:U8",siz, Siz get the run time value)
						OCV:MAT			//OpenCv MAT
						WRP:EXT:yt		//Your Pointer where yt is your type for WRP_DEL 

// ==========================================================================================
*/
#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

//#pragma optimize( "", off ) //Disable Optimization

// =======================================================================
// Your Type Exposed to POWER-KI 
// =======================================================================



// =======================================================================
// THE pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *

	/* Example:
	if(!_wcsicmp(TYP,L"myObjId"))
		{
		delete (myObjPtr*) PTR;
		return;
		}
	*/

	;
	}


// =======================================================================
// your code .. 
// =======================================================================

WRP_FUNC(Sum, Example of: c=a+b)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(int, a, First addend);		
	WRP_DCLPAR_DEF(int, b, 10, Second addend with ten as default value);
	
	WRP_DCLRES(int,c, The Result);

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	c = a + b;
	
	WRP_RET_OK;
	}

// ==========================================================================================
// Remeber to add your function (comma separated list of function name)
// ==========================================================================================

WRP_INIT(Sum);

//#pragma optimize( "", on )
// ==========================================================================================


