/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***					  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-CORE.hpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   Core implementation for user Wrap DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------

  USE :
  ---------------------------------------------------------------------------
  Include this file in your  "Wrap" 

  the wrap function shoud be like:
	
	WRP_FUNC(SUM,Perform a sum)	
		{
		WRP_DCLBEG;

		WRP_DCLPAR(int, a);			// declare an input par
		WRP_DCLPAR_DEF(int, b, 20);	// with default parameter

		WRP_DCLPRES(int, c);			//declare the return value if any

		WRP_DCLEND;					

		//-----------------------------	
		//now your code !! never before
		//-----------------------------

		c=a+b;

		return 1;				// 1=ok  0 or less Error (in POWER-KI -> NULL)
		}
	
  Remember to list your function :

	WRP_INIT(Sum, otherfunction);
	

  Parameter Type:

	I8, U8, I16, U16, I32 int, U32 unsigned, I64, U64, F32 float, F64 double, U_STRG U_CHR*, ANY 

  To declare a PWK PTR res type use:

	WRP_DCLRES_AS(typ,nam,as);
	WRP_DCLRES_AS_WPAY(typ,nam,as,pay); //If it has a variable payLoad like buffer size

  Where "as": 

		IS:		LIB:TAG:TYP:PAY

	 For BUF:		LIB -> BUF 
		and:		TAG -> BUF, CHK		
		and:		TYP -> see above
		and:		PAY -> size in byte
				
	 For MAT:		LIB -> OCV 
		and:		TAG -> MAT		
	 (OpenCv)

		IS:		typ -> (user typ to return in WRP_DEL(ptr,typ) )	

  TRIGGER: a way to call PWK EXO or METHOD from inside your function

	Immediate execution	
	   Sync:		WRP_TRIGSYNC;
				WRP_TRIGSYNC_with(par1,..); //parameter WRP_DCLared and also in TRIG

	Execution in a new Thread (parallel)   	
	   ASyn:		WRP_TRIGPARL;
				WRP_TRIGPARL_with(par1,..);

	Syncronization of TRIG access
				WRP_TRIG_LCKS;				// Lock Set the Trig semaphore
				WRP_TRIG_LCKR;				// Lock ReSet the Trig semaphore 
	
*/

#include "PWK-WRP-STILE.hpp"
#include "PWK-WRP-LISTE.hpp"

#ifndef WRP_EXPORTS
	#define WRP_EXPORTS __declspec(dllexport)
#endif

#define _CRT_SECURE_DEPRECATE_MEMORY
#include <wchar.h>

// ============================================================================
// String Useful Function
// ============================================================================
typedef char		A_CHR;
typedef wchar_t		U_CHR;
typedef U_CHR*		U_STRG;

FUNCTION(int, Return string len)
StrLen(PTR_TO(A_CHR)s)
	{
	if(!s )return 0;
	return strlen(s);
	}

FUNCTION(int, Return string len)
StrLen(PTR_TO(U_CHR)s)
	{
	if(!s )return 0;
	return wcslen(s);
	}

//DESCR(String conversion)
FUNCTION(PTR_TO(U_CHR), From A_CHR to U_CHR - in a new string )
StrAtoU(PTR_TO(A_CHR)s)
	{
	PTR_TO(U_CHR) d;
	PTR_TO(U_CHR) r;
	int len;
	if(!s) return (U_CHR*)NULL;
	len=StrLen(s);
	if(!len) return (U_CHR*)NULL;
	r=d=new U_CHR[len+2];
	
	/*
	//MultiByteToWideChar(CP_ACP, 0, pszA, cCharacters,	*ppszW, cCharacters
	MultiByteToWideChar(CP_ACP,0,s,len,r,len);
	r[len]=0;
	return r;
	*/

	while(*s)
		{
		(*d)=*((U8*)s);
		d++;
		s++;
		}
	(*d)=NULL;
	return r;
	}		

FUNCTION(PTR_TO(A_CHR), From U_CHR to A_CHR - in a new string)
StrUtoA(PTR_TO(U_CHR)s)
	{
	PTR_TO(A_CHR) d;
	PTR_TO(A_CHR) r;
	int len;
	if(!s) return(A_CHR*)NULL;
	len=StrLen(s);
	if(!len) return (A_CHR*)NULL;
	r=d=new A_CHR[len+2];
	
	//WideCharToMultiByte(CP_ACP, 0, pszW, cCharacters, *ppszA,	cbAnsi, NULL, NULL))

	while(*s)
		{
		(*d)=(A_CHR)(*s);
		d++;
		s++;
		}
	(*d)=NULL;
	return r;
	}

FUNCTION(PTR_TO(A_CHR), From U_CHR to U_CHR/UTF - in a new string)
StrUtoUTF(PTR_TO(U_CHR)s)
	{
	int len;
	PTR_TO(A_CHR) ns;
	
	if(!s) return NULL;
	
	NOTE(Get the size)
		
	len=WideCharToMultiByte(CP_UTF8,0,s,-1,NULL,0, 0,0);

	if(!len) return NULL;
	ns=new A_CHR[len+1];	

	WideCharToMultiByte(CP_UTF8,0,s,-1,ns,len, 0,0);
	ns[len]=0;
	return ns;
	}

FUNCTION(PTR_TO(U_CHR), From U_CHR/UTF to U_CHR - in a new string)
StrUTFtoU(PTR_TO(A_CHR)s)
	{
	int len;	
	PTR_TO(U_CHR) ns;
	
	if(!s) return NULL;
	
	len=MultiByteToWideChar(CP_UTF8,0,s,-1,NULL,0);
	if(!len) return NULL;
	
	ns=new U_CHR[len+1];
	MultiByteToWideChar(CP_UTF8,0,s,-1,ns,len);
	ns[len]=0;
	return ns;
	}

FUNCTION(PTR_TO(U_CHR), Duplicate String)
StrDup( const PTR_TO(U_CHR)s)
	{
	if(!s )return NULL;
	unsigned ln= wcslen(s) + 1;
	
	return wmemcpy(new U_CHR[ln],s,ln);
	}	

// ============================================================================

typedef WRP_EXPORTS int(* WRPPWK_EXC)(ANY _parBuf_, int _parNum_, PTR_TO(U8)bpp);
typedef NONE(CALLBACK* WRPPWK_TCB)(ANY, PTR_TO(U_CHR), int mode);// Trig call back 0=Sync 1=asinc 2=Lock SEt 3=Lock RESET


#define PAR2FNC(n)	(n*-1-1)

#pragma pack(push,1)
DEFINE(struct,WRP_PAR)
WRP_PAR
	{
	DATA(PTR_TO(U_CHR),			par,			Par name);
	DATA(int,					off,			offset);
	DATA(int,					siz,			size in byte);
	DATA(PTR_TO(U_CHR),			typ,			Type: U8 I8 I16 U16 I32 U32 I64 U64 F32 F64 PTR   );
	DATA(PTR_TO(U_CHR),			as,				AS: LIB:TAG:TYP:PAY);
	};

DEFINE(struct, WRP_FNC)
WRP_FNC
	{
	DATA(PTR_TO(U_CHR),			fnc,			function name);
	DATA(WRPPWK_EXC,			ptr,			Function Pointer);	
	DATA(int,					np,				Number of parameter);
	DATA(PTR_TO(WRP_PAR),		par,			Ptr to input par);	
	DATA(int,					psz,			Size in byte of par buffer);	
	DATA(int,					nr,				 of res 0=no res);	
	DATA(PTR_TO(WRP_PAR),		res,			Ptr to return par - only one);
	DATA(int,					rsz,			Size in byte of res buffer);	
	};

DEFINE(struct, WRP_TBL)
WRP_TBL
	{
	DATA(int,					nf,			Number of function);
	DATA(PTR_TO(WRP_FNC),		pf,			Ptr to function);
	};

#pragma pack(pop)

/*---------------------------------------------
#define __STR2WSTR(str) L##str
#define _STR2WSTR(str) __STR2WSTR(str)
#define __FUNCTIONW__ _STR2WSTR(__FUNCTION__)
//---------------------------------------------
*/

typedef WRP_EXPORTS PTR_TO(WRP_TBL)(CALLBACK* WRPPWK_GETTBL)(WRPPWK_TCB);
typedef WRP_EXPORTS NONE(CALLBACK* WRPPWK_PTRDEL)(ANY);

PTR_TO(WRP_TBL) wrpTbl=NULL;		// Main data table
WRPPWK_TCB	 PWK_TRIGGER=NULL;		// POWER-KI Trigger CallBack

// =======================================================================

DEFINE(struct, Function poiter container)
lisParElm: public DNODO
	{
	WRP_PAR p;
	};

LIST_OBJ_MNG<lisParElm> lisPar;
LIST_OBJ_MNG<lisParElm> lisRes;

FUNCTION(NONE, Register Parameter)
PWK_WRP_PAR_REG(PTR_TO(U_CHR)id, PTR_TO(U_CHR)typ, int szt)
	{
	PTR_TO(lisParElm) pe=new lisParElm;
	pe->p.par=StrDup(id);
	pe->p.typ=StrDup(typ);
	pe->p.siz=szt;
	lisPar.Add(pe);
	}

FUNCTION(NONE, Register Return res)
PWK_WRP_RES_REG(PTR_TO(U_CHR)id, PTR_TO(U_CHR)typ, int szt)
	{
	PTR_TO(lisParElm) pe=new lisParElm;
	pe->p.par=StrDup(id);
	pe->p.typ=StrDup(typ);
	pe->p.siz=szt;
	pe->p.as=NULL;
	lisRes.Add(pe);
	}

FUNCTION(NONE, Set Func Par)
PWK_WRP_PAR_SET(int idx)
	{
	PTR_TO(WRP_PAR)par;
	PTR_TO(lisParElm) pe;
	int i, in;
	int szt=0;
	int off=sizeof(ANY);
	int sz=0;

	in=wrpTbl->pf[idx].np= lisPar.GetNum();

	if(!in)
		{
		wrpTbl->pf[idx].par = NULL;		
		wrpTbl->pf[idx].psz = 0;				
		}
	else {	
		par=wrpTbl->pf[idx].par = new WRP_PAR[in];
	
		for(i=0; i<in; i++)
			{
			pe=lisPar.Get();
			par[i].off=off;
			par[i].par= pe->p.par;
			par[i].siz=pe->p.siz;
			par[i].typ = pe->p.typ;
			off+= par->siz;
			sz += par->siz;
			delete pe;
			}	
		wrpTbl->pf[idx].psz=sz;
		lisPar.Clean();
		}

	in=wrpTbl->pf[idx].nr= lisRes.GetNum();

	if(!in)
		{
		wrpTbl->pf[idx].res = NULL;		
		wrpTbl->pf[idx].rsz = 0;
		}
	else {			
		par=wrpTbl->pf[idx].res = new WRP_PAR[in];
		sz=0;
		for(i=0; i<in; i++)
			{
			pe=lisRes.Get();
			par[i].off=off;
			par[i].par= pe->p.par;
			par[i].siz=pe->p.siz;
			par[i].typ = pe->p.typ;
			par[i].as = pe->p.as;
			off+= par->siz;
			sz+= par->siz;
			delete pe;
			}	
		wrpTbl->pf[idx].rsz=sz;
		lisRes.Clean();
		}
	}

FUNCTION(PTR_TO(WRP_TBL), Add function to init)
PWK_WRP_Init(WRPPWK_EXC fnc, ...)
	{
	int cnt=0;	
	WRPPWK_EXC fbeg=fnc;

	va_list v1;		
	va_start(v1,fnc);
	
	while(fnc!=NULL)
		{
		cnt++;
		fnc=va_arg(v1, WRPPWK_EXC);
		}
		
	wrpTbl = new WRP_TBL;

	wrpTbl->nf = cnt;
	wrpTbl->pf = new WRP_FNC[cnt];

	fnc = fbeg;
	va_start(v1, fnc);

	cnt=0;
	while(fnc!=NULL)
		{
		wrpTbl->pf[cnt].ptr = fnc;
		(fnc)(NULL,(cnt+1)*-1,NULL);
		PWK_WRP_PAR_SET(cnt);

		cnt++;
		fnc=va_arg(v1, WRPPWK_EXC);
		}
	va_end(v1);

	return wrpTbl;
	}


//------------------------------------------------------
ANY WRP_GETRET(PTR_TO(U_CHR)id, ANY buf, int szt, PTR_TO(U_CHR) typ, const PTR_TO(U_CHR) fun, const PTR_TO(U_CHR)as, int init)
	{
	if (init)
		{	
		PWK_WRP_RES_REG(id, typ, szt); 
		return NULL;
		}
	
	int i,in, y, yn;
	PTR_TO(WRP_PAR)par;

	in= wrpTbl->nf;

	for(i=0; i<in; i++)
		{
		if(!_wcsicmp(fun,wrpTbl->pf[i].fnc))
			{
			par = wrpTbl->pf[i].res;
			yn= wrpTbl->pf[i].nr;

			for(y=0; y<yn; y++)
				{
				if(!_wcsicmp(id, par[y].par))
					{
					if (par[y].as)delete par[y].as;
					par[y].as=StrDup(as);
					return &((U8*)buf)[par[y].off];
					}
				}			
			}
		}
	return NULL;
	}

//------------------------------------------------------

int WRP_GETPAR_IDX(PTR_TO(U_CHR)id,const PTR_TO(U_CHR) fun)
	{
	int i,in, y, yn;
	PTR_TO(WRP_PAR)par;

	in= wrpTbl->nf;

	for(i=0; i<in; i++)
		{
		if(!_wcsicmp(fun,wrpTbl->pf[i].fnc))
			{
			par = wrpTbl->pf[i].par;
			yn= wrpTbl->pf[i].np;

			for(y=0; y<yn; y++)
				{
				if(!_wcsicmp(id, par[y].par))
					{
					return y;
					}
				}			
			}
		}

	return -1;
	}

ANY WRP_GETPAR(PTR_TO(U_CHR)id, ANY buf, int szt, const PTR_TO(U_CHR) fun)
	{
	int i,in, y, yn;
	PTR_TO(WRP_PAR)par;

	in= wrpTbl->nf;

	for(i=0; i<in; i++)
		{
		if(!_wcsicmp(fun,wrpTbl->pf[i].fnc))
			{
			par = wrpTbl->pf[i].par;
			yn= wrpTbl->pf[i].np;

			for(y=0; y<yn; y++)
				{
				if(!_wcsicmp(id, par[y].par))
					{
					return &((U8*)buf)[par[y].off];
					}
				}			
			}
		}
	return NULL;
	}

ANY WRP_SET_DCLPAR(int pn, PTR_TO(U_CHR)nam, PTR_TO(U_CHR)typ, int tySz, ANY parBuf, PTR_TO(U_CHR)FUNCTIONW)
	{
	if(pn< 0)
		{		
		PWK_WRP_PAR_REG((U_CHR*)nam, (U_CHR*)typ, tySz);
		return NULL;
		}
	return WRP_GETPAR(nam, parBuf, tySz, FUNCTIONW);		
	}

// -----------------------------------------------------------------------
FUNCTION(PTR_TO(U_CHR), Build an AS return signature e.g. for BUF size)
WRP_RES_PAY(const PTR_TO(U_CHR)fxp,unsigned pay)
	{
	PTR_TO(U_CHR) b=new U_CHR[50];

	wsprintfW(b,L"%s:%d",fxp,pay);
	return b;
	}

// -----------------------------------------------------------------------	
#define	WRP_DCLBEG \
if(_parNum_<0) wrpTbl->pf[PAR2FNC(_parNum_)].fnc=StrDup((U_CHR*)__FUNCTIONW__);	\
ANY& _wtp_= *(ANY*)&((U8*)_parBuf_)[0];

#define WRP_DCLEND	if(_parNum_<0) return 1;
//------------------------------------------------------

#define WRP_DCLPAR(typ,nam, ...) \
	typ &nam =*(typ*) WRP_SET_DCLPAR(_parNum_,(U_CHR*)L#nam,(U_CHR*)L#typ,sizeof(typ),_parBuf_, (U_CHR*) __FUNCTIONW__);

#define WRP_DCLPAR_DEF(typ,nam,def, ...) \
	typ &nam =*(typ*) WRP_SET_DCLPAR(_parNum_,(U_CHR*)L#nam,(U_CHR*)L#typ,sizeof(typ),_parBuf_, (U_CHR*) __FUNCTIONW__);\
	if(_parNum_>0 && _bpp_)\
		{\
		int idx=WRP_GETPAR_IDX((U_CHR*)L#nam,(U_CHR*) __FUNCTIONW__);\
		if(idx>=0)\
			{\
			if(_bpp_[idx]==0)\
				{\
				nam=def; \
				} \
			} \
		}
//------------------------------------------------------
#define WRP_DCLRES(typ,nam, ...) \
	typ &nam= *(typ*) WRP_GETRET((U_CHR*)L#nam, _parBuf_, sizeof(typ),(U_CHR*) L#typ,(U_CHR*) __FUNCTIONW__,NULL, _parNum_< 0);

#define WRP_DCLRES_AS(typ,nam,as, ...) \
	typ &nam= *(typ*) WRP_GETRET((U_CHR*)L#nam, _parBuf_, sizeof(typ), (U_CHR*)L#typ,(U_CHR*) __FUNCTIONW__, (U_CHR*) as, _parNum_< 0);

#define WRP_DCLRES_AS_WPAY(typ, nam, as, pay, ...) \
	PTR_TO(U_CHR)pas= (U_CHR*)as;\
	if(_parNum_>= 0)\
		{\
		pas = WRP_RES_PAY(as, pay);\
		}\
	typ &nam= *(typ*) WRP_GETRET((U_CHR*)L#nam, _parBuf_, sizeof(typ), (U_CHR*)L#typ,(U_CHR*) __FUNCTIONW__, (U_CHR*) pas, _parNum_< 0);\
	if(_parNum_>= 0 && pas)\
		{\
		delete pas;\
		}

// -----------------------------------------------------------------------
extern "C" NONE WRP_CALL_PWK_TRIG(ANY parTrg, PTR_TO(U_CHR)parLis, int mode)
	{
	(PWK_TRIGGER)(parTrg, parLis, mode); \
	}

#define WRP_TRIGSYNC \
	if(_wtp_)\
		{\
		WRP_CALL_PWK_TRIG(_wtp_, NULL,0 );\
		}

#define WRP_TRIGPARL\
	if(_wtp_)\
		{\
		WRP_CALL_PWK_TRIG(_wtp_, NULL,1 );\
		}

#define WRP_TRIGSYNC_With(...) \
	if(_wtp_)\
		{\
		WRP_CALL_PWK_TRIG(_wtp_,(U_CHR*) L#__VA_ARGS__,0 );\
		}

#define WRP_TRIGPARL_With(...)\
	if(_wtp_)\
		{\
		WRP_CALL_PWK_TRIG(_wtp_, (U_CHR*) L#__VA_ARGS__,1 );\
		}

// Set / Reset TRIG Smf
#define WRP_TRIG_LCKS\
	if(_wtp_)\
		{\
		WRP_CALL_PWK_TRIG(_wtp_, NULL,2);\
		}

#define WRP_TRIG_LCKR\
	if(_wtp_)\
		{\
		WRP_CALL_PWK_TRIG(_wtp_, NULL,3);\
		}

// -----------------------------------------------------------------------
#define WRP_DEL(PTR,TYP, ...)\
FUNCTION(extern "C" WRP_EXPORTS NONE, Delete User created pointer) \
PWK_PTRDEL(ANY PTR, PTR_TO(U_CHR) TYP)

// -----------------------------------------------------------------------
#define WRP_FUNC(nam,...) extern "C" \
	int nam (ANY _parBuf_, int _parNum_, PTR_TO(U8) _bpp_)

// -----------------------------------------------------------------------

#define WRP_INIT(...) \
extern "C" \
WRP_EXPORTS PTR_TO(WRP_TBL) PWK_GETTBL(WRPPWK_TCB trig) \
	{ \
	if(trig)PWK_TRIGGER=trig;\
	if(!wrpTbl)\
		{\
		return PWK_WRP_Init(__VA_ARGS__,NULL,NULL);\
		}\
	return wrpTbl;\
	}

// -----------------------------------------------------------------------
#define WRP_RET_OK		return 1
#define WRP_RET_ERR		return 0
// =======================================================================
// PWK WRP - END
// =======================================================================





