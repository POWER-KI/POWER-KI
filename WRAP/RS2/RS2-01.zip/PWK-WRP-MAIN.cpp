/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***					  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/

#include <librealsense2/rs.hpp> 
#include <librealsense2/rsutil.h>


#include <windows.h>

using namespace std;


// ==========================================================================================
// PWK WRP
// ==========================================================================================


#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

//#pragma optimize( "", off ) //Disable Optimization

// =======================================================================
// Your Type Exposed to POWER-KI 
// =======================================================================

DEFINE(struct, RS2_PTR)
RS2_PTR
	{
	rs2::pipeline pipe;
	PTR_TO(rs2::align) align_to_depth;
	PTR_TO(rs2::align)align_to_color;
	int ref;	

	DATA(int,		run,		Running);
	RS2_PTR()
		{
		run=0;
		ref=1;
		align_to_depth= new rs2::align(rs2_stream::RS2_STREAM_DEPTH);
		align_to_color= new rs2::align(rs2_stream::RS2_STREAM_COLOR);
		};

	~RS2_PTR()
		{
		delete align_to_color;
		delete align_to_depth;
		}
	};

DEFINE(struct, RS2_FRM) //Frame
RS2_FRM
	{
	rs2::frameset data;
	PTR_TO(RS2_PTR) rs2;

	RS2_FRM(PTR_TO(RS2_PTR) rt)
		{
		rt->ref++;
		rs2=rt;
		}

	~RS2_FRM()
		{
		rs2->ref --;
		if(rs2->ref==0) delete rs2;		
		}
	};

//-----------------------------
//substitution for #include <cv-helpers.hpp> //In RealSense 
//-----------------------------

#define TRACE(t) WRP_PWK_EXEC(t);

#define BFsiz 250
ANY PWK_frame_to_mat(const rs2::frame& f)
	{
	using namespace rs2;

	int sz;
	U_CHR buf[BFsiz];

	PTR_TO(U8) dt;
	ANY PBF=NULL;		
	ANY RES=NULL;
	
	if(!f) return RES;
	
	auto vf = f.as<video_frame>();
	const int w = vf.get_width();
	const int h = vf.get_height();
	
	sz = f.get_data_size();

	if (sz <= 0) return RES;
			
	//Create a PWK BUF CHK(chunk) so it can be delete safety because the data are preserved 			
	
	//dt = new U8[sz];
	//memcpy((ANY)dt, (ANY)f.get_data(), sz);

	dt= (U8*)f.get_data();
	StrFormat(buf, BFsiz, (U_CHR*)L"BUF:CHK:RS2:%d", sz);
	PBF = WRP_PTR_NEW(dt, buf);
	
	switch (f.get_profile().format())
		{
		case RS2_FORMAT_BGR8:
			{
			//Create the PWK code to execute
			StrFormat(buf,BFsiz,(U_CHR*)L"�t1=OCV_MAT(�NEW,%d,%d,�CV_8UC3,%d);�t2=OCV_MAT(�T1,�CLN);Trash(�t1);�t2",w,h,PBF );			
			}break;

		case RS2_FORMAT_RGB8:
			{
			//Note in PWK implementation of OCV transformation and operation preserve the source, so if no more needed should be trashed
			StrFormat(buf, BFsiz,(U_CHR*)L"�t1=OCV_MAT(�NEW,%d,%d,�CV_8UC3,%d);�t2=OCV_MAT(�t1,�CNVCLR,4);Trash(�t1);�t2",w,h,PBF );			
			// 4= COLOR_BGR2RGB
						
			}break;

		case RS2_FORMAT_Z16:
			{			
			StrFormat(buf, BFsiz,(U_CHR*)L"�t1=OCV_MAT(�NEW,%d,%d,�CV_16UC1,%d);�t2=OCV_MAT(�T1,�CLN);Trash(�t1);�t2",w,h,PBF );
			}break;

		case RS2_FORMAT_Y8:
			{			
			StrFormat(buf, BFsiz,(U_CHR*)L"�t1=OCV_MAT(�NEW,%d,%d,�CV_8UC1,%d);�t2=OCV_MAT(�T1,�CLN);Trash(�t1);�t2",w,h,PBF );
			}break;

		case RS2_FORMAT_DISPARITY32:
			{
			StrFormat(buf, BFsiz, (U_CHR*)L"�t1=OCV_MAT(�NEW,%d,%d,�CV_32FC1,%d);�t2=OCV_MAT(�T1,�CLN);Trash(�t1);�t2", w, h, PBF);
			}break;
		}

	RES = WRP_PWK_EXEC(buf);

	WRP_PTR_DEL(PBF);

	return RES;
	}

// Converts depth frame to a matrix of doubles with distances in meters
ANY depth_frame_to_meters(const rs2::pipeline& pipe, const rs2::depth_frame& f)
	{
	using namespace rs2;
	U_CHR buf[BFsiz];	

	ANY dm = PWK_frame_to_mat(f);
	ANY RES=NULL;
	
	if(!dm) return NULL;

	FLT depth_scale = pipe.get_active_profile()
		.get_device()
		.first<depth_sensor>()
		.get_depth_scale();

	StrFormat(buf, BFsiz, (U_CHR*)L"�t=%s;�t1=OCV_MAT(�t,�CNV,�CV_64F);�t2=OCV_OP(�t1, �MUL, %f);TRASH(�t,�t1);�t2", dm, depth_scale);
	
	delete dm;
	
	RES = WRP_PWK_EXEC(buf);
	return RES;
	}



FUNCTION(float, Calculate euclidean distance between the two points)
dist_3d(const rs2::depth_frame& frame,  int ux, int uy, int vx, int vy)
	{
		float upixel[2]; // From pixel
		float upoint[3]; // From point (in 3D)

		float vpixel[2]; // To pixel
		float vpoint[3]; // To point (in 3D)

					  // Copy pixels into the arrays (to match rsutil signatures)
		upixel[0] = ux;
		upixel[1] = uy;
		vpixel[0] = vx;
		vpixel[1] = vy;

		// Query the frame for distance
		// Note: this can be optimized
		// It is not recommended to issue an API call for each pixel
		// (since the compiler can't inline these)
		// However, in this example it is not one of the bottlenecks
		auto udist = frame.get_distance(upixel[0], upixel[1]);
		auto vdist = frame.get_distance(vpixel[0], vpixel[1]);

		// Deproject from pixel to point in 3D
		rs2_intrinsics intr = frame.get_profile().as<rs2::video_stream_profile>().get_intrinsics(); // Calibration data
		rs2_deproject_pixel_to_point(upoint, &intr, upixel, udist);
		rs2_deproject_pixel_to_point(vpoint, &intr, vpixel, vdist);
		

		// Calculate euclidean distance between the two points
		
		return sqrt(pow(upoint[0] - vpoint[0], 2) +
				pow(upoint[1] - vpoint[1], 2) +
				pow(upoint[2] - vpoint[2], 2));
	}

// =======================================================================
// THE pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, PAY, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *
	// PAY is ANY

	if(!PTR) return;
	
	switch(StrSelect(TYP,(U_CHR*)L"RS2,FRM"))
		{
		case 1: //RS2
			{
			PTR_TO(RS2_PTR) rs2= (RS2_PTR*)PTR;
			if (rs2->ref>0) rs2->ref--;
			if(rs2->ref==0) delete rs2;
			}break;

		case 2: //FRM
			{
			delete (RS2_FRM*) PTR;
			}break;
		}
	}

	

// =======================================================================
// your code .. 
// =======================================================================

WRP_FUNC(VER, "Return version number" )
	{	
	WRP_DCLBEG;

	WRP_DCLRES(U_STRG, ver,L"Version" );	

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	ver=StrDup((U_CHR*)L"2.35");

	WRP_RET_OK;
	}

// -------------------------------------

WRP_FUNC(NEW, "Create" )
	{	
	WRP_DCLBEG;

	WRP_DCLRES_AS(res,L"WRP:EXT:RS2" ,"Pointer");	//Implicit RS2

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	
	res= new RS2_PTR();
	WRP_RET_OK;
	}

WRP_FUNC(CMD, "Start, Stop" )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR_DEF(ANY, ptr, NULL, "Pointer");		
	WRP_DCLPAR_DEF(U_STRG, wht, NULL, "�START, �STOP");		

	WRP_DCLRES(int,res);	

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_TO(RS2_PTR) rs2=NULL;	
	
	if(ptr==NULL)
		{
		WRP_RET_ERR;
		}

	if(StrCmp_I((U_CHR*)WRP_PTR(ptr, TYP), (U_CHR*)L"RS2"))
		{		
		WRP_RET_ERR;
		}

	rs2= (RS2_PTR*)WRP_PTR(ptr, PTR);

	WRP_PTR_LCKS(ptr);

	switch (StrSelect(wht,(U_CHR*) L"START,STOP"))
		{
		case 0: 
		case 1:
			{
			if (!rs2->run)
				{
				try	{
					rs2::config cfg;

					cfg.enable_all_streams();

					rs2->pipe.start(cfg);
					rs2->run = 1;
					}
				catch (const std::exception& e)
					{
					WRP_PTR_LCKR(ptr);
					WRP_RET_ERR;
					}				
				}
			}break;

		case 2:
			{
			if (rs2->run)
				{
				rs2->pipe.stop();
				rs2->run = 0;
				}
			}break;
		}
	
	res=rs2->run;
	WRP_PTR_LCKR(ptr);
	WRP_RET_OK;
	}


WRP_FUNC(Read, "Read " )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR_DEF(ANY, ptr, NULL, "Poiter");		
	WRP_DCLPAR_DEF(U_STRG, par1, NULL, "�ALGN_DPT, �ALGN_CLR");		

	WRP_DCLRES_AS(res, L"WRP:EXT:FRM"); //implicit FRM

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_TO(RS2_PTR) rs2=NULL;
	PTR_TO(RS2_FRM) frm=NULL;
	
	if(ptr==NULL)
		{
		WRP_RET_ERR;
		}

	if(StrCmp_I((U_CHR*)WRP_PTR(ptr, TYP), (U_CHR*)L"RS2"))
		{		
		WRP_RET_ERR;
		}

	rs2 = (RS2_PTR*)WRP_PTR(ptr, PTR);

	if(!rs2->run)
		{
		WRP_RET_ERR;
		}
	
	WRP_PTR_LCKS(ptr);

	frm=new RS2_FRM(rs2);

	if(!rs2->pipe.try_wait_for_frames(&frm->data))
		{
		delete frm;
		res=NULL;

		WRP_PTR_LCKR(ptr);
		WRP_RET_ERR;
		}
	
	switch(StrSelect(par1,(U_CHR*)L"ALGN_DPT, ALGN_CLR"))
		{
		case 1:
			{
			frm->data = rs2->align_to_depth->process(frm->data);
			}break;

		case 2:
			{
			frm->data = rs2->align_to_color->process(frm->data);
			}break;
		}

	res=frm;	

	WRP_PTR_LCKR(ptr);
	WRP_RET_OK;
	}

WRP_FUNC(GetMat, "Get From frame " )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR_DEF(ANY, ptr, NULL, "Poiter");		
	WRP_DCLPAR_DEF(U_STRG, wht, NULL, "�CLR(def), �DPT, �DPTCLR, DPTMTR �IFR");			

	WRP_DCLRES(U_STRG, res,"OCV mat");	

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_TO(RS2_PTR) rs2=NULL;
	PTR_TO(RS2_FRM) frm=NULL;
	
	ANY mt=NULL;
	rs2::frame fr;	

	if(ptr==NULL)
		{
		WRP_RET_ERR;
		}

	if(StrCmp_I((U_CHR*)WRP_PTR(ptr, TYP), (U_CHR*)L"FRM"))
		{		
		WRP_RET_ERR;
		}	
	frm = (RS2_FRM*)WRP_PTR(ptr, PTR);


	switch(StrSelect(wht,(U_CHR*)L"CLR,IFR,DPT,DPTCLR,DPTMTR"))
		{
		case 0:
		case 1:
			{
			fr = frm->data.get_color_frame();
			mt = PWK_frame_to_mat(fr);
			}break;

		case 2:
			{
			fr = frm->data.get_infrared_frame();
			mt = PWK_frame_to_mat(fr);
			}break;

		case 3:
			{
			fr = frm->data.get_depth_frame();
			
			if (fr.get_data_size()>0)
				{
				mt = PWK_frame_to_mat(fr);
				}

			}break;

		case 4:
			{
			fr = frm->data.get_depth_frame();
			if (fr.get_data_size()>0)
				{
				rs2::colorizer color_map;
				rs2::frame t;
				try {
					t = color_map.colorize(fr);
					if(t) mt = PWK_frame_to_mat(t);
					}
				catch (const std::exception& e)
					{
					WRP_RET_ERR;						
					}
				}
			}break;

		case 5:
			{
			rs2 = (RS2_PTR*) frm->rs2;

			if (!rs2)
				{
				WRP_RET_ERR;					
				}

			fr = frm->data.get_depth_frame();
					
			if (fr.get_data_size()>0)
				{
				try {
					mt = depth_frame_to_meters(rs2->pipe, fr);
					}
				catch (const std::exception& e)
					{
					WRP_RET_ERR;						
					}
				}

			}break;
		}

	if(!mt)
		{ 
		WRP_RET_ERR;
		}
		
	res=(U_STRG)mt;

	WRP_RET_OK;
	}

WRP_FUNC(Msr, "Measure the distance between two points " )
	{	
	WRP_DCLBEG;

	WRP_DCLPAR_DEF(ANY, ptr, NULL, "Pointer");			
	WRP_DCLPAR_DEF(int, x1, 0);
	WRP_DCLPAR_DEF(int, y1, 0);
	WRP_DCLPAR_DEF(int, x2, 0);
	WRP_DCLPAR_DEF(int, y2, 0);

	WRP_DCLRES(F32,mis,L"distance");	

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_TO(RS2_PTR) rs2=NULL;
	PTR_TO(RS2_FRM) frm=NULL;
	
	if(ptr==NULL)
		{
		WRP_RET_ERR;
		}

	if(StrCmp_I((U_CHR*)WRP_PTR(ptr, TYP), (U_CHR*)L"FRM"))
		{		
		WRP_RET_ERR;
		}	
	frm = (RS2_FRM*)WRP_PTR(ptr, PTR);

	rs2::frame fr;

	mis=0;
	
	fr = frm->data.get_depth_frame();
	if (fr.get_data_size() > 0)
		{
		try {
			mis = dist_3d(fr,x1, y1, x2, y2);
			}
		catch (const std::exception& e)
			{
			WRP_RET_ERR;					
			}
		}		

	WRP_RET_OK;
	}

// ==========================================================================================
// Remeber to add your function (comma separated list of function name)
// ==========================================================================================

WRP_INIT(VER, NEW, CMD, Read, GetMat, Msr);

//#pragma optimize( "", on )
// ==========================================================================================


