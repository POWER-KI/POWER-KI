/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                      Tel/Fax +39 030 2350035
    *** RESERVED ***					(C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN-00.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/

#include <windows.h>

#include <speechapi_cxx.h>

using namespace std;
using namespace Microsoft::CognitiveServices::Speech;

// ==========================================================================================
// PWK WRP
// ==========================================================================================
/* Parameter Type:	I8, U8, I16, U16, I32 int, U32 unsigned, I64, U64, 
				F32 float, F64 double, U_STRG U_CHR*, ANY

   KeyWORD:		WRP_DCLBEG;	  			//Section Begin
	
				WRP_DCLPAR(typ, parName, Comment);	
				WRP_DCLPAR_DEF(typ, parName, defValue, Comment);

				WRP_DCLRES(resName, Comment);	//Return Value (Only The Fst is returned)
				WRP_DCLRES_AS(resName, stringAs, Comment);

				WRP_DCLEND;				//Section End

				WRP_TRIGSYNC;				// Trigger call
				WRP_TRIGPARL;
				WRP_TRIGSYNC_With( par/resName enum);
				WRP_TRIGPARL_With( par/resName enum);

				WRP_TRIG_LCKS;				// Lock Set the Trig semaphore 
				WRP_TRIG_LCKR;				// Lock Reset the Trig semaphore 

				WRP_INIT(FuncName );		//comma separated list of function

   stringAs:		LIB:TAG:TYP:PAY

				example	BUF:BUF:U8:10	//Buffer
						OCV:MAT		//OpenCv MAT
						WRP:EXT:yt	//Your Pointer where yt is your type for WRP_DEL 

// ==========================================================================================
*/
#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

#pragma optimize( "", off )

// =======================================================================
// DELETE Your Type Exposed to POWER-KI 
// =======================================================================

DEFINE(struct, Voice recognizer)
VC_RCGZ
	{
	std::shared_ptr<SpeechRecognizer> sr;
	DATA(volatile int,			 stop,		=end wait);
	DATA(volatile int,			 running,		=end wait);

	VC_RCGZ()
		{
		stop=0;
		running=0;
		};

	~VC_RCGZ()
		{
		stop=1;
		while(running)
			{
			Sleep(10);
			}				
		};
	};

// =======================================================================
// THE pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, PAY, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *
	// PAY is ANY
	
	if (!_wcsicmp(TYP, L"RCGZ"))
		{
		delete (VC_RCGZ*)PTR;
		return;
		}
	}




// =======================================================================
// your code .. 
// =======================================================================

WRP_FUNC(Init, Init Voice)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, SubscriptionKey);		//declare an input par
	WRP_DCLPAR(U_STRG, ServiceRegion);
	WRP_DCLPAR(U_STRG, lang);					// it-IT
	WRP_DCLPAR_DEF(int, OutFormat, 0);			// 0=Simple 1=detailed

	WRP_DCLRES_AS(rcgz,L"WRP:EXT:RCGZ");		//declare the return value if any

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	PTR_TO(A_CHR)sk=StrUtoA(SubscriptionKey);
	PTR_TO(A_CHR)sr = StrUtoA(ServiceRegion);
	PTR_TO(A_CHR)lg = StrUtoA(lang);

	auto config = SpeechConfig::FromSubscription(sk, sr);

	if(OutFormat==1)
		{
		config->SetOutputFormat(OutputFormat::Detailed);
		}

	auto sourceLanguageConfig = SourceLanguageConfig::FromLanguage(lg);

	if (sk)delete sk;
	if (sr)delete sr;
	if (lg)delete lg;
	// ---------------------------------	

	// Creates a speech recognizer
	rcgz=(ANY)new VC_RCGZ();
	((VC_RCGZ*)rcgz)->sr = SpeechRecognizer::FromConfig(config, sourceLanguageConfig);
	

	WRP_RET_OK;				// 1=ok  0 or less Error (in POWER-KI -> NULL)
	}

WRP_FUNC(WaitText, Wait for text)
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);		//declare an input par
	WRP_DCLRES(U_STRG,txt);		//declare the return value if any

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	
	if (((VC_RCGZ*)rcgz)->running>0)  WRP_RET_ERR;

	((VC_RCGZ*)rcgz)->running++;
	auto result = ((VC_RCGZ*)rcgz)->sr->RecognizeOnceAsync().get();

	if (result->Reason != ResultReason::RecognizedSpeech) 
		{
		((VC_RCGZ*)rcgz)->running--;
		WRP_RET_ERR;
		}

	txt= StrUTFtoU((A_CHR*)(result->Text).c_str());			

	((VC_RCGZ*)rcgz)->running--;
	WRP_RET_OK;
	};

ANY WTP = NULL;
#define recognizer ((VC_RCGZ*)rcgz)->sr

WRP_FUNC(ListenBeg, Listen continuosly )
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);			//declare an input par
	WRP_DCLPAR_DEF(U32, prvFlg,1);	//preview 0=off 1=on

	WRP_DCLRES(I32, res);		//Exit result
	WRP_DCLRES(U_STRG,txt);		//TEXT 
	WRP_DCLRES(U64, off);		//Offset
	WRP_DCLRES(U64, dur);		//duration
	WRP_DCLRES(U_STRG,prv);		// preview TEXT 
	WRP_DCLRES(U_STRG, knd);	// PRV or TXT 

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	WTP = _wtp_;
	volatile int stop=0;
	volatile int disc = 1;

	if (((VC_RCGZ*)rcgz)->running>0)  WRP_RET_ERR;

	((VC_RCGZ*)rcgz)->running++;

	std::shared_ptr<SpeechRecognitionResult> pR;
	std::shared_ptr<SpeechRecognitionResult> tR;

	int cntP=0;
	int tncP = 0;

	int cntR = 0;
	int tncR = 0;

	// Subscribes to events.
	recognizer->Recognizing.Connect([&prvFlg,&tncP, &cntP,&pR](const SpeechRecognitionEventArgs& e)
		{
		if(prvFlg && tncP == cntP)
			{		
			pR = e.Result;
			cntP++;
			}
		});

	recognizer->Recognized.Connect([&tncR, &cntR, &tR](const SpeechRecognitionEventArgs& e)
		{
		if (e.Result->Reason == ResultReason::RecognizedSpeech && tncR == cntR)
			{		
			tR = e.Result;
			cntR++;
			}

		else if (e.Result->Reason == ResultReason::NoMatch)
			{
			;
			}
		});
	

	//=============================================

	recognizer->Canceled.Connect([&stop](const SpeechRecognitionCanceledEventArgs& e)
		{
		switch (e.Reason)
			{
			case CancellationReason::Error:	
									
				stop=1;
			break;

			default:;
			}
		});

	recognizer->SessionStopped.Connect([&stop](const SessionEventArgs& e)
		{		
		stop=2; // Notify to stop recognition.
		});

	recognizer->Recognizing.Disconnect([&disc](const EventArgs& e)
		{
		disc = 1;
		});

	recognizer->StartContinuousRecognitionAsync().wait();

	//=============================================
	
	while(1)
		{
		if(cntP != tncP)
			{
			if ( _wtp_ != WTP)
				{			
				_wtp_ = WTP;
				}

			prv = StrUTFtoU((A_CHR*)(pR->Text).c_str());
			knd = (U_CHR*) L"PRV";
			WRP_TRIGPARL_With(prv, knd);			
			if(prv)delete prv; prv = NULL;
			tncP = cntP;
			}

		if(cntR != tncR)
			{
			if ( _wtp_ != WTP)
				{
				_wtp_ = WTP;
				}
			txt = StrUTFtoU((A_CHR*)(tR->Text).c_str());
			knd = (U_CHR*) L"TXT";
			WRP_TRIGPARL_With(txt, knd);			
			if(txt) delete txt; txt = NULL;
			tncR = cntR;
			}
		if (cntP != tncP || cntR != tncR)continue;

		if(stop || ((VC_RCGZ*)rcgz)->stop)
			{
			break;
			}

		Sleep(0);
		}
	
	//=============================================

	recognizer->StopContinuousRecognitionAsync().wait();
	
	Sleep(100);

	recognizer->Recognizing.DisconnectAll();
	
	while (!disc)
		{
		Sleep(5);
		}

	res=stop;

	((VC_RCGZ*)rcgz)->running--;

	WRP_RET_OK;
	};

WRP_FUNC(Enable, Enable or Disable )
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);		//declare an input par
	WRP_DCLPAR(int, enb);		// 1=yes

	WRP_DCLEND;
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	if(enb)
		{ 
		((VC_RCGZ*)rcgz)->sr->Enable();
		}
	else{
		((VC_RCGZ*)rcgz)->sr->Disable();
		}

	WRP_RET_OK;
	}


WRP_FUNC(ListenEnd, Listen continuosly )
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);		//declare an input par

	WRP_DCLEND;
	//-----------------------------
	//now your code !! never before
	//-----------------------------

	((VC_RCGZ*)rcgz)->stop=1;
	while(((VC_RCGZ*)rcgz)->running>0)
		{
		Sleep(50);
		}

	((VC_RCGZ*)rcgz)->stop = 0;
	WRP_RET_OK;
	}

// ==========================================================================================
// Remeber to add your function (comma separated list of function name)
// ==========================================================================================


WRP_INIT(Init, WaitText, ListenBeg, ListenEnd, Enable);

#pragma optimize( "", on )
// ==========================================================================================


