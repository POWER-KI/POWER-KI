/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                      Tel/Fax +39 030 2350035
    *** RESERVED ***					(C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN-00.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  GLUE
   Task                 :  
   ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/

#include <windows.h>

#include <speechapi_cxx.h>

using namespace std;
using namespace Microsoft::CognitiveServices::Speech;

// ==========================================================================================
// PWK WRP
// ==========================================================================================

#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

#pragma optimize( "", off )

// =======================================================================
// DELETE Your Type Exposed to POWER-KI 
// =======================================================================

#define PTR_RCGZ\
	if(!rcgz) WRP_RET_ERR;\
	rcgz=WRP_PTR(rcgz,PTR);\
	if(!rcgz) WRP_RET_ERR;

DEFINE(struct, Voice recognizer)
VC_RCGZ
	{
	std::shared_ptr<SpeechRecognizer> sr;
	DATA(volatile int,			 stop,		=end wait);
	DATA(volatile int,			 running,		=end wait);

	VC_RCGZ()
		{
		stop=0;
		running=0;
		};

	~VC_RCGZ()
		{
		stop=1;
		while(running)
			{
			Sleep(10);
			}				
		};
	};

// =======================================================================
// THE pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, PAY, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *
	// PAY is ANY
	
	if (!StrCmp_I(TYP,(U_CHR*) L"RCGZ"))
		{
		delete (VC_RCGZ*)PTR;
		return;
		}
	}

void LOG(PTR_TO(U_CHR)s)
{
	FILE* log;
	log = fopen("C:\\PWK-TMP\\WRAPLOG.txt", "a+");

	fwprintf(log, L"\r\n%s", s);
	fclose(log);
	
}

void LOG(PTR_TO(A_CHR)s)
{
	FILE* log;
	log = fopen("C:\\PWK-TMP\\WRAPLOG.txt", "a+");

	fprintf(log, "\r\n%s", s);
	fclose(log);

}



// =======================================================================
// your code .. 
// =======================================================================
WRP_FUNC(VER, "Return version number")
{
	WRP_DCLBEG;

	WRP_DCLRES(U_STRG, ver, L"Version");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	ver = ver = StrDup((U_CHR*)L"1.0");

	WRP_RET_OK;
}

WRP_FUNC(Init, Init Voice)
	{	
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, SubscriptionKey);		//declare an input par
	WRP_DCLPAR(U_STRG, ServiceRegion);
	WRP_DCLPAR(U_STRG, lang);				// it-IT
	WRP_DCLPAR_DEF(int, OutFormat, 0);			// 0=Simple 1=detailed

	WRP_DCLRES_AS(rcgz,L"RCGZ");				//declare implicit the return value if any

	WRP_DCLEND;
	
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_TO(A_CHR)sk = StrUtoA(SubscriptionKey);
	PTR_TO(A_CHR)sr = StrUtoA(ServiceRegion);
	PTR_TO(A_CHR)lg = StrUtoA(lang);

	auto config = SpeechConfig::FromSubscription(sk, sr);

	if(OutFormat==1)
		{
		config->SetOutputFormat(OutputFormat::Detailed);
		}

	auto sourceLanguageConfig = SourceLanguageConfig::FromLanguage(lg);

	if (sk)delete sk;
	if (sr)delete sr;
	if (lg)delete lg;
	// ---------------------------------	

	// Creates a speech recognizer
	rcgz=(ANY)new VC_RCGZ();

	try	{
		((VC_RCGZ*)rcgz)->sr = SpeechRecognizer::FromConfig(config, sourceLanguageConfig);
		}
	catch (...)
		{
		delete (VC_RCGZ*) rcgz;
		WRP_RET_ERR;
		}

	WRP_RET_OK;				// 1=ok  0 or less Error (in POWER-KI -> NULL)
	}

WRP_FUNC(WaitText, Wait for text)
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);		//declare an input par
	WRP_DCLRES(U_STRG,txt);		//declare the return value if any

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	PTR_RCGZ;

	if (((VC_RCGZ*)rcgz)->running>0)  WRP_RET_ERR;

	((VC_RCGZ*)rcgz)->running++;
	auto result = ((VC_RCGZ*)rcgz)->sr->RecognizeOnceAsync().get();

	if (result->Reason != ResultReason::RecognizedSpeech) 
		{
		((VC_RCGZ*)rcgz)->running--;
		WRP_RET_ERR;
		}

	txt= StrUTFtoU((A_CHR*)(result->Text).c_str());			

	((VC_RCGZ*)rcgz)->running--;
	WRP_RET_OK;
	};

ANY WTP = NULL;
#define recognizer ((VC_RCGZ*)rcgz)->sr

WRP_FUNC(ListenBeg, Listen continuosly )
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);			//declare an input par
	WRP_DCLPAR_DEF(U32, prvFlg,1);	//preview 0=off 1=on

	WRP_DCLRES(I32, res);		//Exit result
	WRP_DCLRES(U_STRG,txt);		//TEXT 
	WRP_DCLRES(U64, off);		//Offset
	WRP_DCLRES(U64, dur);		//duration
	WRP_DCLRES(U_STRG,prv);		// preview TEXT 
	WRP_DCLRES(U_STRG, knd);	// PRV or TXT 

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	PTR_RCGZ;

	WTP = _wtp_;
	volatile int stop=0;
	volatile int disc = 1;

	if (((VC_RCGZ*)rcgz)->running>0)  WRP_RET_ERR;

	((VC_RCGZ*)rcgz)->running++;

	std::shared_ptr<SpeechRecognitionResult> pR;
	std::shared_ptr<SpeechRecognitionResult> tR;

	int cntP=0;
	int tncP = 0;

	int cntR = 0;
	int tncR = 0;

	// Subscribes to events.
	
	/*
	recognizer->Recognizing.Connect([&prvFlg,&tncP, &cntP,&pR](const SpeechRecognitionEventArgs& e)
		{
		if(prvFlg && tncP == cntP)
			{		
			pR = e.Result;
			cntP++;
			}
		});

	recognizer->Recognized.Connect([&tncR, &cntR, &tR](const SpeechRecognitionEventArgs& e)
		{
		if (e.Result->Reason == ResultReason::RecognizedSpeech && tncR == cntR)
			{
			tR = e.Result;
			cntR++;
			}

		else if (e.Result->Reason == ResultReason::NoMatch)
			{
			;
			}
		});

	*/

	recognizer->Recognizing.Connect([&prv,&knd, &_wtp_,&rcgz, &stop](const SpeechRecognitionEventArgs& e)
		{	
		if(!stop)
			{
			PTR_TO(U_CHR)pt;
			WRP_PTR_LCKS(rcgz);
				
			pt= StrUTFtoU((A_CHR*)(e.Result->Text.c_str()));
			if(StrCmp(pt,prv))
				{
				prv=pt;
				knd = (U_CHR*)L"PRV";
				WRP_TRIGPARL_With(prv, knd);
				}
			if (pt)delete pt;
				
			WRP_PTR_LCKR(rcgz);

			/*
				WRP_PTR_LCKS(rcgz);
				prv = StrUTFtoU((A_CHR*)(e.Result->Text.c_str()));
				knd = (U_CHR*)L"PRV";
				WRP_TRIGPARL_With(prv, knd);
				if (prv)delete prv; prv = NULL;			
				WRP_PTR_LCKR(rcgz);
			*/
			}
					
		});

	recognizer->Recognized.Connect([&txt, &knd, &_wtp_, &rcgz, &stop, &cntR](const SpeechRecognitionEventArgs& e)
		{
		if (e.Result->Reason == ResultReason::RecognizedSpeech)
			{		
			if (!stop)
				{
				PTR_TO(U_CHR)pt;
				WRP_PTR_LCKS(rcgz);
				
				pt= StrUTFtoU((A_CHR*)(e.Result->Text.c_str()));
				if(StrCmp(pt,txt))
					{
					txt=pt;
					knd = (U_CHR*)L"TXT";
					WRP_TRIGPARL_With(txt, knd);
					}
				if (pt)delete pt;
				
				WRP_PTR_LCKR(rcgz);
				}			
			}

		else if (e.Result->Reason == ResultReason::NoMatch)
			{
			;
			}
		});

	//=============================================

	recognizer->Canceled.Connect([&stop, &rcgz](const SpeechRecognitionCanceledEventArgs& e)
		{
		switch (e.Reason)
			{
			case CancellationReason::Error:	
				WRP_PTR_LCKS(rcgz);
				stop=1;
				WRP_PTR_LCKR(rcgz);
			break;

			default:;
			}
		});

	recognizer->SessionStopped.Connect([&stop, &rcgz](const SessionEventArgs& e)
		{		
		WRP_PTR_LCKS(rcgz);
		stop=2; // Notify to stop recognition.
		WRP_PTR_LCKR(rcgz);
		});

	recognizer->Recognizing.Disconnect([&disc, &rcgz](const EventArgs& e)
		{
		WRP_PTR_LCKS(rcgz);
		disc = 1;
		WRP_PTR_LCKR(rcgz);
		});

	recognizer->StartContinuousRecognitionAsync().wait();

	//=============================================
	
	while(1)
		{
		/*
		if(cntP != tncP)
			{
			if ( _wtp_ != WTP)
				{			
				_wtp_ = WTP;
				}

			prv = StrUTFtoU((A_CHR*)(pR->Text).c_str());
			knd = (U_CHR*) L"PRV";
			WRP_TRIGPARL_With(prv, knd);			
			if(prv)delete prv; prv = NULL;
			pR=nullptr;
			tncP = cntP;			
			}

		if(cntR != tncR)
			{
			if ( _wtp_ != WTP)
				{
				_wtp_ = WTP;
				}
			txt = StrUTFtoU((A_CHR*)(tR->Text).c_str());
			knd = (U_CHR*) L"TXT";
			WRP_TRIGPARL_With(txt, knd);			
			if(txt) delete txt; txt = NULL;
			tR = nullptr;
			tncR = cntR;
			}
		if (cntP != tncP || cntR != tncR)continue;
		*/

		if(stop || ((VC_RCGZ*)rcgz)->stop)
			{
			if(((VC_RCGZ*)rcgz)->stop)stop=1;
			break;
			}

		Sleep(100);
		}
	
	//=============================================
	Sleep(100);

	WRP_PTR_LCKS(rcgz);
	recognizer->StopContinuousRecognitionAsync().wait();
	WRP_PTR_LCKR(rcgz);

	Sleep(200);

	WRP_PTR_LCKS(rcgz);
	recognizer->Recognizing.DisconnectAll();
	WRP_PTR_LCKR(rcgz);
	
	while (!disc)
		{
		Sleep(50);
		}

	Sleep(100);
	res=stop;

	((VC_RCGZ*)rcgz)->running--;

	WRP_RET_OK;
	};

WRP_FUNC(Enable, Enable or Disable )
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);		//declare an input par
	WRP_DCLPAR(int, enb);		// 1=yes

	WRP_DCLEND;
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_RCGZ;

	if(enb)
		{ 
		((VC_RCGZ*)rcgz)->sr->Enable();
		}
	else{
		((VC_RCGZ*)rcgz)->sr->Disable();
		}

	WRP_RET_OK;
	}


WRP_FUNC(ListenEnd, Listen continuosly )
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, rcgz);		//declare an input par

	WRP_DCLEND;
	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PTR_RCGZ;

	((VC_RCGZ*)rcgz)->stop=1;
	while(((VC_RCGZ*)rcgz)->running>0)
		{
		Sleep(50);
		}

	((VC_RCGZ*)rcgz)->stop = 0;
	WRP_RET_OK;
	}

// ==========================================================================================
// Remeber to add your function (comma separated list of function name)
// ==========================================================================================

WRP_INIT(VER, Init, WaitText, ListenBeg, ListenEnd, Enable);

#pragma optimize( "", on )
// ==========================================================================================


