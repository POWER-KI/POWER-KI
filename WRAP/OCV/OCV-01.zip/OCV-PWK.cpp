/* ======================  ===================================================
		 XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
	 www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***				  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  OCV-PWK.cpp
   Version              :  01
   Date                 :  25/11/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI
   Workpakage           :  WRAP
   Task                 :  OCV
  ----------------------  ---------------------------------------------------
   License              :  APACHE 2
  ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   OpenCv support
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/
#include <windows.h>
#include "OCV-PWK.hpp"

ANY UpdateMat(PTR_TO(OCV_MAT)ocv)
	{
	U_STRG frm;
	U_CHR buf[201];
					
	ocv->chnSz= ocv->mat.elemSize();
	ocv->elmSz= ocv->mat.elemSize1();
	ocv->cTyp= ocv->mat.type();
	ocv->eTyp= ocv->mat.depth();
	ocv->tot= ocv->mat.total();
	ocv->dims= ocv->mat.dims;
	ocv->rows= ocv->mat.rows;
	ocv->cols= ocv->mat.cols;
	ocv->chn= ocv->mat.channels();
	ocv->dat = ocv->mat.data;
	ocv->datSiz = ocv->mat.rows * ocv->mat.step.p[0];
		
	ocv->cTypS.SetS(OCV_MAT_CTYP(ocv->mat.type()));
	ocv->eTypS.SetS(OCV_MAT_ETYP(ocv->mat.depth()));

	ocv->flg_cont= ocv->mat.isContinuous();
	ocv->flg_sub = ocv->mat.isSubmatrix();
	ocv->stp= ocv->mat.step.p[0];

	switch(ocv->chnSz)
		{
		case 1: frm = L"Format8bppIndexed"; break; 
		case 2: frm=L"Format16bppRgb555";break;
		case 3: frm = L"Format24bppRgb"; break;
		case 4: frm = L"Format32bppArgb"; break;
		default: frm = L"Canonical"; break;// questo da eccezione perch� non comincia con format
		}
	
	/*
	L"Alpha, Canonical,DontCare,Format16bppArgb1555,Format16bppGrayScale,Format16bppRgb555,
	Format16bppRgb565,Format1bppIndexed,Format24bppRgb,Format32bppArgb,Format32bppPArgb,Format32bppRgb,
	Format48bppRgb,Format4bppIndexed,Format64bppArgb,Format64bppPArgb,Format8bppIndexed,Gdi,Indexed,Max,PAlph,Undefined"))
	*/

	//StrFormat(buf,200, L"width=%d, heigh=%d, line=%d, pxf=%s ", ocv->cols, ocv->rows, ocv->cols*ocv->chnSz,frm);
	StrFormat(buf, 200, L"width=%d, heigh=%d, line=%d, pxf=%s ", ocv->cols, ocv->rows, ocv->stp, (U_STRG)frm);
	ocv->winFmt=buf;
	
	return ocv;	
	}

void MtxFill(PTR_TO(BUF_MTX_DATA)mtx,PTR_TO(OCV_MAT)ocv, ANY buf, PTR_TO(U_CHR)ty)
	{
	XU_VAL x;
	//ocv->elmSzc / ocv->elmSze;
	int nec=ocv->chn;
				
	mtx->mnd=2;

	if(nec >1)mtx->mnd++;

	mtx->esz=ocv->elmSz;
	mtx->ten=ocv->tot * nec;
	mtx->msz= ocv->datSiz;
	mtx->dim= new unsigned[mtx->mnd];
	mtx->dim[1]=ocv->cols;
	mtx->dim[0] = ocv->rows;
	if(mtx->mnd==3)mtx->dim[2] = nec;
	mtx->pkp=buf;
	mtx->typ=ty;		
	};



PTR_TO(OCV_MAT) CreateMat(cv::Mat mat)
	{		
	PTR_TO(OCV_MAT)m =new OCV_MAT;
	m->mat=mat;
	UpdateMat(m);

	return m;
	}


PTR_TO(OCV_VCP) CreateVcp(PTR_TO(U_CHR)s, int API)
	{
	XU_VAL sel=s;		

	PTR_TO(OCV_VCP) ocv=new OCV_VCP;

	if(~sel)
		{
		if(sel.IsNum())
			{	
			ocv->vcp = cv::VideoCapture::VideoCapture(int(sel),API);
			}
		else {
			PTR_TO(A_CHR)an = StrUtoA(s);
			cv::String n = an;
			delete an;
			ocv->vcp = cv::VideoCapture::VideoCapture(n,API);
			}
		}
	else {
		ocv->vcp = cv::VideoCapture::VideoCapture();
		}

	if( ocv->vcp.isOpened())
		{		
		return ocv;
		}
	else delete ocv;

	return NULL;
	}

/*
enum VideoCaptureAPIs {
CAP_ANY          = 0,            //!< Auto detect == 0
CAP_VFW          = 200,          //!< Video For Windows (obsolete, removed)
CAP_V4L          = 200,          //!< V4L/V4L2 capturing support
CAP_V4L2         = CAP_V4L,      //!< Same as CAP_V4L
CAP_FIREWIRE     = 300,          //!< IEEE 1394 drivers
CAP_FIREWARE     = CAP_FIREWIRE, //!< Same value as CAP_FIREWIRE
CAP_IEEE1394     = CAP_FIREWIRE, //!< Same value as CAP_FIREWIRE
CAP_DC1394       = CAP_FIREWIRE, //!< Same value as CAP_FIREWIRE
CAP_CMU1394      = CAP_FIREWIRE, //!< Same value as CAP_FIREWIRE
CAP_QT           = 500,          //!< QuickTime (obsolete, removed)
CAP_UNICAP       = 600,          //!< Unicap drivers (obsolete, removed)
CAP_DSHOW        = 700,          //!< DirectShow (via videoInput)
CAP_PVAPI        = 800,          //!< PvAPI, Prosilica GigE SDK
CAP_OPENNI       = 900,          //!< OpenNI (for Kinect)
CAP_OPENNI_ASUS  = 910,          //!< OpenNI (for Asus Xtion)
CAP_ANDROID      = 1000,         //!< Android - not used
CAP_XIAPI        = 1100,         //!< XIMEA Camera API
CAP_AVFOUNDATION = 1200,         //!< AVFoundation framework for iOS (OS X Lion will have the same API)
CAP_GIGANETIX    = 1300,         //!< Smartek Giganetix GigEVisionSDK
CAP_MSMF         = 1400,         //!< Microsoft Media Foundation (via videoInput)
CAP_WINRT        = 1410,         //!< Microsoft Windows Runtime using Media Foundation
CAP_INTELPERC    = 1500,         //!< RealSense (former Intel Perceptual Computing SDK)
CAP_REALSENSE    = 1500,         //!< Synonym for CAP_INTELPERC
CAP_OPENNI2      = 1600,         //!< OpenNI2 (for Kinect)
CAP_OPENNI2_ASUS = 1610,         //!< OpenNI2 (for Asus Xtion and Occipital Structure sensors)
CAP_GPHOTO2      = 1700,         //!< gPhoto2 connection
CAP_GSTREAMER    = 1800,         //!< GStreamer
CAP_FFMPEG       = 1900,         //!< Open and record video file or stream using the FFMPEG library
CAP_IMAGES       = 2000,         //!< OpenCV Image Sequence (e.g. img_%02d.jpg)
CAP_ARAVIS       = 2100,         //!< Aravis SDK
CAP_OPENCV_MJPEG = 2200,         //!< Built-in OpenCV MotionJPEG codec
CAP_INTEL_MFX    = 2300,         //!< Intel MediaSDK
CAP_XINE         = 2400,         //!< XINE engine (Linux)
};
*/

PTR_TO(OCV_VWR) CreateVwr(PTR_TO(U_CHR)s, PTR_TO(U_CHR)f4, double fps,int szx,int szy)
	{	
	XU_VAL sel=s,fcc=f4;	
	PTR_TO(OCV_VWR) ocv=NULL;
	/*
	fourcc 4 - character code of codec used to compress the frames.For example,
		VideoWriter::fourcc('P', 'I', 'M', '1') is a MPEG - 1 codec, VideoWriter::fourcc('M', 'J', 'P', 'G') is a
		motion - jpeg codec etc.List of codes can be obtained at[Video Codecs by FOURCC]
		(http://www.fourcc.org/codecs.php) page.
	*/	

	cv::Size fsz(szx,szy);
	int isc=1;	
	
	if(~sel)
		{
		PTR_TO(A_CHR)an = StrUtoA(s);
		cv::String n = an;
		delete an;
	
		int fourcc= (int)fcc;
		if( fourcc != -1)
			{
			an= StrUtoA(fcc);
			fourcc=cv::VideoWriter::fourcc(an[0],an[1],an[2],an[3]);
			delete an;
			}

		ocv = new OCV_VWR;
		ocv->szx=szx;
		ocv->szy=szy;

		if(ocv->vwr.open(n,fourcc,fps,fsz,isc))
			{
			return ocv;
			}
		else delete ocv;
		}
	
	return NULL;
	}



FUNCTION(PTR_TO(U_CHR), Giving a symbol defined in enum return the value)
EnumDecode(PTR_TO(U_CHR)v, PTR_TO(U_CHR)e)
	{
	XU_VAL s;
	PTR_TO(U_CHR)b;
	
	b=XU_VAL_TMP(e).Find(v);

	if(!b) return NULL;

	b = XU_VAL_TMP(b).Find(L"=");
	if (!b) return NULL;

	b++;
	if(XU_VAL_TMP(b).Find(L","))
		{
		s.SetS(XU_VAL_TMP(b).GetUpToChr(L","));
		}
	else s=b;
	
	Nospaces(s);
	return s.Reset();
	}


FUNCTION(PTR_TO(U_CHR), from the code of an OCV ELEMENT TYPE return the name)
OCV_MAT_ETYP(int t)
	{
	XU_VAL r;
	switch(t)
		{
		case CV_8U: r= L"CV_8U";break;//- 8 - bit unsigned integers(0..255)
		case CV_8S: r = L"CV_8S"; break;//- 8 - bit signed integers(-128..127)
		case CV_16U: r = L"CV_16U"; break;//- 16 - bit unsigned integers(0..65535)
		case CV_16S: r = L"CV_16S"; break;//- 16 - bit signed integers(-32768..32767)
		case CV_32S: r = L"CV_32S"; break;//- 32 - bit signed integers(-2147483648..2147483647)
		case CV_32F: r = L"CV_32F"; break;//- 32 - bit floating - point numbers(-FLT_MAX..FLT_MAX, INF, NAN)
		case CV_64F: r = L"CV_64F"; break;// - 64 - bit floating - point numbers(-DBL_MAX..DBL_MAX, INF, NAN)
		case CV_16F: r = L"CV_16F"; break;// - 164 - bit floating  
		}
	return r.Reset();
	} 

FUNCTION(int, from the name of an OCV ELEMENT TYPE return the code)
OCV_MAT_ETYP(PTR_TO(U_CHR) t)
	{
	int d=1,c=1;
	XU_VAL r;
	XU_VAL l;
	
	//Formato tipo U8 , CV_U8, U8Cx, CV_U8Cx
	
	l=t;
	Nospaces(l);

	if(StrStr_I(l,L"U")) 
		{
		r.SetS(XU_VAL_TMP(l).GetFromChr_I(L'U'));
		l.SetS(XU_VAL_TMP(l).GetUpToChr_I(L'U')); l <<= L'U';		
		}
	else {
		if (StrStr_I(l, L"S"))
			{
			r.SetS(XU_VAL_TMP(l).GetFromChr_I(L'S'));
			l.SetS(XU_VAL_TMP(l).GetUpToChr_I(L'S')); l <<= L'S';
			}
		else {
			if (StrStr_I(l, L"F"))
				{
				r.SetS(XU_VAL_TMP(l).GetFromChr_I(L'F'));
				l.SetS(XU_VAL_TMP(l).GetUpToChr_I(L'F')); l <<= L'F';
				}
			}
		}

	if(StrStr(l,L"_"))
		{
		l.SetS(l.GetFromChr(L"_"));
		}
	
	switch(StrSelect(l,L"8U,8S,16U,16S,32S,32F,64F,16F") )
		{
		default:	return 0;
		case 1:	d=CV_8U;break;
		case 2:	d = CV_8S; break;
		case 3:	d = CV_16U; break;
		case 4:	d = CV_16S; break;
		case 5:	d = CV_32S; break;
		case 6:	d = CV_32F; break;
		case 7:	d = CV_64F; break;
		case 8:	d = CV_16F; break;
		}
	
	return d; 
	} 


FUNCTION(PTR_TO(U_CHR), from the code of an OCV CHANNEL TYPE return the name)
OCV_MAT_CTYP(int t)
	{
	XU_VAL r;
	XU_VAL c;	

	c= (t >> CV_CN_SHIFT) +1;
	t= t & 0b111;
	
	switch(t)
		{
		case CV_8U: r=L"CV_8U";break;//- 8 - bit unsigned integers(0..255)
		case CV_8S: r = L"CV_8S"; break;//- 8 - bit signed integers(-128..127)
		case CV_16U: r = L"CV_16U"; break;//- 16 - bit unsigned integers(0..65535)
		case CV_16S: r = L"CV_16S"; break;//- 16 - bit signed integers(-32768..32767)
		case CV_32S: r = L"CV_32S"; break;//- 32 - bit signed integers(-2147483648..2147483647)
		case CV_32F: r = L"CV_32F"; break;//- 32 - bit floating - point numbers(-FLT_MAX..FLT_MAX, INF, NAN)
		case CV_64F: r = L"CV_64F"; break;// - 64 - bit floating - point numbers(-DBL_MAX..DBL_MAX, INF, NAN)
		case CV_16F: r = L"CV_16F"; break;// - 16 - bit floating - 
		}

	r <<=L"C";
	r <<=c;

	return r.Reset();
	} 

FUNCTION(int, from the name of an OCV CHANNEL TYPE return the code)
OCV_MAT_CTYP(PTR_TO(U_CHR) t)
	{
	int d=1,c=1;
	XU_VAL r;
	XU_VAL l;
	
	//Formato tipo U8 , CV_U8, U8Cx, CV_U8Cx
	
	l=t;
	Nospaces(l);

	if(StrStr_I(l,L"U")) 
		{
		r.SetS(XU_VAL_TMP(l).GetFromChr_I(L'U'));
		l.SetS(XU_VAL_TMP(l).GetUpToChr_I(L'U')); l <<= L'U';		
		}
	else {
		if (StrStr_I(l, L"S"))
			{
			r.SetS(XU_VAL_TMP(l).GetFromChr_I(L'S'));
			l.SetS(XU_VAL_TMP(l).GetUpToChr_I(L'S')); l <<= L'S';
			}
		else {
			if (StrStr_I(l, L"F"))
				{
				r.SetS(XU_VAL_TMP(l).GetFromChr_I(L'F'));
				l.SetS(XU_VAL_TMP(l).GetUpToChr_I(L'F')); l <<= L'F';
				}
			}
		}

	if(StrStr(l,L"_"))
		{
		l.SetS(l.GetFromChr(L"_"));
		}
	
	switch(StrSelect(l,L"8U,8S,16U,16S,32S,32F,64F,16F") )
		{
		default:	return 0;
		case 1:	d = CV_8U;break;
		case 2:	d = CV_8S; break;
		case 3:	d = CV_16U; break;
		case 4:	d = CV_16S; break;
		case 5:	d = CV_32S; break;
		case 6:	d = CV_32F; break;
		case 7:	d = CV_64F; break;
		case 8:	d = CV_16F; break;
		}	

	if(~r)
		{
		r.SetS(r.GetFromChr_I(L"C"));
		if(r.Find(L"(")) 
			{
			r.SetS(r.GetFromChr(L"("));
			r.SetS(r.GetUpToChr(L")"));
			}				
		c=(unsigned)r;
		c=MIN(c,16);
		}

	return (CV_MAT_DEPTH(d) + (((c)-1) << CV_CN_SHIFT));
	} 

PTR_TO(U_CHR) GetOcvInf(PTR_TO(OCV_MAT)ocv, PTR_TO(U_CHR)key)
	{
	XU_VAL rs;
	switch (StrSelect(key, OCV_DATA_STRING,1,L';'))
		{
		case 1: rs=ocv->cols;break;
		case 2: rs = ocv->rows; break;
		case 3: rs = ocv->datSiz; break;
		case 4: rs = ocv->tot; break;//Totale Elementi
		case 5: rs = ocv->chn; break;//Numero canali
		case 6: rs = ocv->cTypS; break; //Tipo Canale : like CV_16SC3		
		case 7: rs = ocv->chnSz; break; //in Byte dimensione canale		
		case 8: rs = ocv->eTypS; break; //Tipo elementi: like CV_16S
		case 9: rs = ocv->elmSz; break;//in byte dimensione elemento
		case 10: rs = ocv->winFmt; break; //stringa formato: WIDTH=%d, heigh=%d, line=%d, pxf=%s
		}
	return rs.Reset();
	}



FUNCTION(PTR_TO(U_CHR), Return the code of OCV color names)
CNVCLR_CODE(PTR_TO(U_CHR)p)
	{
	return EnumDecode(p,
				   L"COLOR_BGR2BGRA = 0, 	\
					COLOR_RGB2RGBA = 0,\
					COLOR_BGRA2BGR = 1, \
					COLOR_RGBA2RGB = 1,\
					COLOR_BGR2RGBA = 2, \
					COLOR_RGBA2BGR = 3, \
					COLOR_BGR2RGB = 4, \
					COLOR_BGRA2RGBA = 5, \
					COLOR_BGR2GRAY = 6, \
					COLOR_RGB2GRAY = 7, \
					COLOR_GRAY2BGR = 8,\
					COLOR_GRAY2BGRA = 9,\
					COLOR_BGRA2GRAY = 10,\
					COLOR_RGBA2GRAY = 11, \
					COLOR_BGR2BGR565 = 12, \
					COLOR_RGB2BGR565 = 13, \
					COLOR_BGR5652BGR = 14, \
					COLOR_BGR5652RGB = 15, \
					COLOR_BGRA2BGR565 = 16, \
					COLOR_RGBA2BGR565 = 17, \
					COLOR_BGR5652BGRA = 18, \
					COLOR_BGR5652RGBA = 19, \
					COLOR_GRAY2BGR565 = 20, \
					COLOR_BGR5652GRAY = 21, \
					COLOR_BGR2BGR555 = 22, \
					COLOR_RGB2BGR555 = 23, \
					COLOR_BGR5552BGR = 24, \
					COLOR_BGR5552RGB = 25, \
					COLOR_BGRA2BGR555 = 26, \
					COLOR_RGBA2BGR555 = 27, \
					COLOR_BGR5552BGRA = 28, \
					COLOR_BGR5552RGBA = 29, \
					COLOR_GRAY2BGR555 = 30, \
					COLOR_BGR5552GRAY = 31, \
					COLOR_BGR2XYZ = 32, \
					COLOR_RGB2XYZ = 33, \
					COLOR_XYZ2BGR = 34, \
					COLOR_XYZ2RGB = 35, \
					COLOR_BGR2YCrCb = 36, \
					COLOR_RGB2YCrCb = 37, \
					COLOR_YCrCb2BGR = 38, \
					COLOR_YCrCb2RGB = 39, \
					COLOR_BGR2HSV = 40, \
					COLOR_RGB2HSV = 41, \
					COLOR_BGR2Lab = 44, \
					COLOR_RGB2Lab = 45, \
					COLOR_BGR2Luv = 50, \
					COLOR_RGB2Luv = 51, \
					COLOR_BGR2HLS = 52, \
					COLOR_RGB2HLS = 53, \
					COLOR_HSV2BGR = 54, \
					COLOR_HSV2RGB = 55, \
					COLOR_Lab2BGR = 56, \
					COLOR_Lab2RGB = 57, \
					COLOR_Luv2BGR = 58, \
					COLOR_Luv2RGB = 59, \
					COLOR_HLS2BGR = 60, \
					COLOR_HLS2RGB = 61, \
					COLOR_BGR2HSV_FULL = 66, \
					COLOR_RGB2HSV_FULL = 67, \
					COLOR_BGR2HLS_FULL = 68, \
					COLOR_RGB2HLS_FULL = 69, \
					COLOR_HSV2BGR_FULL = 70, \
					COLOR_HSV2RGB_FULL = 71, \
					COLOR_HLS2BGR_FULL = 72, \
					COLOR_HLS2RGB_FULL = 73, \
					COLOR_LBGR2Lab = 74, \
					COLOR_LRGB2Lab = 75, \
					COLOR_LBGR2Luv = 76, \
					COLOR_LRGB2Luv = 77, \
					COLOR_Lab2LBGR = 78, \
					COLOR_Lab2LRGB = 79, \
					COLOR_Luv2LBGR = 80, \
					COLOR_Luv2LRGB = 81, \
					COLOR_BGR2YUV = 82, \
					COLOR_RGB2YUV = 83, \
					COLOR_YUV2BGR = 84, \
					COLOR_YUV2RGB = 85, \
					COLOR_YUV2RGB_NV12 = 90,\
					COLOR_YUV2BGR_NV12 = 91, \
					COLOR_YUV2RGB_NV21 = 92, \
					COLOR_YUV2BGR_NV21 = 93, \
					COLOR_YUV2RGBA_NV12 = 94, \
					COLOR_YUV2BGRA_NV12 = 95, \
					COLOR_YUV2RGBA_NV21 = 96, \
					COLOR_YUV2BGRA_NV21 = 97, \
					COLOR_YUV2RGB_YV12 = 98, \
					COLOR_YUV2BGR_YV12 = 99, \
					COLOR_YUV2RGB_IYUV = 100, \
					COLOR_YUV2BGR_IYUV = 101, \
					COLOR_YUV2RGBA_YV12 = 102, \
					COLOR_YUV2BGRA_YV12 = 103, \
					COLOR_YUV2RGBA_IYUV = 104, \
					COLOR_YUV2BGRA_IYUV = 105, \
					COLOR_YUV2GRAY_420 = 106, \
					COLOR_YUV2RGB_UYVY = 107, \
					COLOR_YUV2BGR_UYVY = 108, \
					COLOR_YUV2RGB_VYUY = 109, \
					COLOR_YUV2BGR_VYUY = 110, \
					COLOR_YUV2RGBA_UYVY = 111, \
					COLOR_YUV2BGRA_UYVY = 112, \
					COLOR_YUV2RGB_YUY2 = 115, \
					COLOR_YUV2BGR_YUY2 = 116, \
					COLOR_YUV2RGB_YVYU = 117, \
					COLOR_YUV2BGR_YVYU = 118, \
					COLOR_YUV2RGBA_YUY2 = 119, \
					COLOR_YUV2BGRA_YUY2 = 120, \
					COLOR_YUV2RGBA_YVYU = 121, \
					COLOR_YUV2BGRA_YVYU = 122, \
					COLOR_YUV2GRAY_UYVY = 123, \
					COLOR_YUV2GRAY_YUY2 = 124, \
					COLOR_RGBA2mRGBA = 125, \
					COLOR_mRGBA2RGBA = 126, \
					COLOR_RGB2YUV_I420 = 127, \
					COLOR_BGR2YUV_I420 = 128, \
					COLOR_RGBA2YUV_I420 = 129, \
					COLOR_BGRA2YUV_I420 = 130, \
					COLOR_RGB2YUV_YV12 = 131, \
					COLOR_BGR2YUV_YV12 = 132, \
					COLOR_RGBA2YUV_YV12 = 133, \
					COLOR_BGRA2YUV_YV12 = 134, \
					COLOR_BayerBG2BGR = 46, \
					COLOR_BayerGB2BGR = 47, \
					COLOR_BayerRG2BGR = 48, \
					COLOR_BayerGR2BGR = 49, \
					COLOR_BayerBG2GRAY = 86, \
					COLOR_BayerGB2GRAY = 87, \
					COLOR_BayerRG2GRAY = 88, \
					COLOR_BayerGR2GRAY = 89, \
					COLOR_BayerBG2BGR_VNG = 62, \
					COLOR_BayerGB2BGR_VNG = 63, \
					COLOR_BayerRG2BGR_VNG = 64, \
					COLOR_BayerGR2BGR_VNG = 65, \
					COLOR_BayerBG2BGR_EA = 135, \
					COLOR_BayerGB2BGR_EA = 136, \
					COLOR_BayerRG2BGR_EA = 137, \
					COLOR_BayerGR2BGR_EA = 138, \
					COLOR_BayerBG2BGRA = 139, \
					COLOR_BayerGB2BGRA = 140, \
					COLOR_BayerRG2BGRA = 141, \
					COLOR_BayerGR2BGRA = 142, \
					COLOR_COLORCVT_MAX = 143");
};

