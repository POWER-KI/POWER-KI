/* ======================  ===================================================
           XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
      www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***				  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI  
   Workpakage           :  WRAP
   Task                 :  OCV
  ----------------------  ---------------------------------------------------
   License              :  APACHE 2
  ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/


#include <windows.h>

using namespace std;

// ==========================================================================================
// PWK WRP
// ==========================================================================================


//#include "PWK-WRP-CORE-01.hpp"
#include "OCV-PWK.hpp"



//#pragma optimize( "", off ) //Disable Optimization

// =======================================================================
// Your Type Exposed to POWER-KI 
// =======================================================================

ANY GET_OCV_PTR( ANY p, PTR_TO(U_CHR)ty)
	{
	XU_VAL LIB,  TYP;

	if (p)
		{
		LIB = (U_CHR*)WRP_PTR(p, LIB);
		TYP = (U_CHR*)WRP_PTR(p, TYP);

		if (LIB == L"OCV" && TYP == ty)
			{
			return WRP_PTR(p, PTR);			
			}		
		}
	return NULL;
	}

ANY GET_OCV_PTR(PTR_TO(U_CHR) p, PTR_TO(U_CHR)ty)
	{
	XU_VAL t=p;
	return GET_OCV_PTR((ANY) (unsigned) t, ty);
	}

// =======================================================================
// Your pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, PAY, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *
	// PAY is ANY

	if(!PTR)return;
	XU_VAL msg;

	if(!PTR) return;

	switch(StrSelect(TYP, L"MAT,VCP,VWR,BKS,CCL"))
		{
		default:	msg= L"OCV DEL - Unknown Typ: ";
				msg <<= TYP;
				WRP_TRACE(msg);break;

		case 1: delete (OCV_MAT*)PTR; break;
		case 2: delete (OCV_VCP*)PTR; break;
		case 3: delete (OCV_VWR*)PTR; break;
		case 4: delete (OCV_BKS*)PTR; break;
		case 5: delete (OCV_CCL*)PTR; break;
		}
	}



// =======================================================================
// your code .. 
// =======================================================================

WRP_FUNC(VER, "Return version number")
	{
	WRP_DCLBEG;

	WRP_DCLRES(U_STRG, ver, L"Version");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	ver =StrDup(L"4.5.1");

	WRP_RET_OK;
	}


WRP_FUNC(MAT, "Create a new mat")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, wht);
	WRP_DCLPAR_DEF(U_STRG, P1,NULL);
	WRP_DCLPAR_DEF(U_STRG, P2, NULL);
	WRP_DCLPAR_DEF(U_STRG, P3, NULL);
	WRP_DCLPAR_DEF(U_STRG, P4, NULL);
	WRP_DCLPAR_DEF(U_STRG, P5, NULL);

	WRP_DCLRES_AS(res,L"MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	cv::Mat m;
	XU_VAL LIB,TAG,TYP;	
	ANY dat=NULL;
	
	if (!_parNum_)
		{
		res = (ANY)CreateMat(m);
		WRP_RET_OK;
		}

	if(XU_VAL_TMP(wht)==L"NEW")
		{
		int col=(int)XU_VAL_TMP(P1);
		int row = (int)XU_VAL_TMP(P2);
		PTR_TO(U_CHR) typ=(U_CHR*)P3;
		ANY buf = (ANY)(unsigned) XU_VAL_TMP(P4);
		int stp = (int)XU_VAL_TMP(P5);

		if (buf)
			{
			LIB= (U_CHR*)WRP_PTR(buf, LIB);
			TAG= (U_CHR*)WRP_PTR(buf, TAG);
			TYP= (U_CHR*)WRP_PTR(buf, TYP);

			if (LIB == L"BUF") 
				{
				if (TAG == L"BUF" || TAG == L"CNK")
					{
					dat= WRP_PTR(buf, PTR);
					}
				m = cv::Mat(row, col, OCV_MAT_CTYP((U_CHR*)typ), dat, stp);
				}
			}
		else {
			m = cv::Mat(row, col, OCV_MAT_CTYP((U_CHR*)typ));
			}

		res = (ANY)CreateMat(m);	

		WRP_RET_OK;
		}

		
	PTR_TO(OCV_MAT) ocv=(OCV_MAT*)GET_OCV_PTR(wht, L"MAT");

	if(!ocv)WRP_RET_ERR;

	if (~XU_VAL_TMP(P1) == 0)
		{
		UpdateMat(ocv);
		WRP_SETRES_AS(res, NULL); //Change as to NULL so avoid the creation of a new pointer
		res=ocv;

		WRP_RET_OK;
		}


	XU_VAL p2	= P2;
	XU_VAL p3 = P3;
	XU_VAL p4 = P4;

	switch(StrSelect(P1,L"CLN,CPYTO,CNV,CNVCLR,GETMTX,GETBUF"))
		{
		case 1://CLN
			{
			m=ocv->mat.clone();
			res = CreateMat(m);
			WRP_RET_OK;
			}break;

		case 2://CPYTO
			{
			cv::Mat md;
			int upd=0;
			PTR_TO(OCV_MAT)d=NULL; // P2= dst
			PTR_TO(OCV_MAT)msk=NULL; //(OPT)P3= mask			

			if(~p2==0) // Se non c'� lo crea
				{					
				d= (OCV_MAT*)CreateMat(md);
				upd=1;
				}
			else {
				d = (OCV_MAT*)GET_OCV_PTR(p2, L"MAT");
				}

			if (!d)
				{					
				WRP_RET_ERR;
				}

			if(~p3)
				{
				msk = (OCV_MAT*)GET_OCV_PTR(P3, L"MAT");
				}

			if(msk)
				{
				if(ocv->mat.total() != msk->mat.total())
					{
					if(upd) WRP_PTR_DEL(d);					
					WRP_RET_ERR;
					}
				ocv->mat.copyTo(d->mat,msk->mat);
				}
			else {
				ocv->mat.copyTo(d->mat);
				}

			if(upd)
				{ 
				UpdateMat(d);
				res=d;
				}
			else {
				WRP_SETRES_AS(res, NULL);
				res = (ANY)(unsigned)p2;
				}
			
			WRP_RET_OK;
			}break;

		case 3://CNV
			{
			cv::Mat md;
			double alpha=1;
			double beta=0;
	
			if(~p3)alpha= p3;
			if (~p4)beta = p4;

			try  {
				ocv->mat.convertTo(md, OCV_MAT_ETYP(P2), alpha , beta ) ;
				}
			catch (...)
				{
				WRP_RET_ERR;
				}

			res = CreateMat(md);
			WRP_RET_OK;				
			}break;

		case 4: //CNVCLR
			{
			cv::Mat md;
			int dstCn=0;
			
			if(p3.IsNum() ) dstCn=(int)p3;
			
			if(!p2.IsNum())
				{				
				p2.SetS( CNVCLR_CODE(p2));
				}

			if (!p2.IsNum())
				{
				WRP_RET_ERR ;
				}
			
			try  {
				cv::cvtColor(ocv->mat, md, p2, dstCn);
				}
			catch(...)
				{
				WRP_RET_ERR;
				}

			res = CreateMat(md);
			WRP_RET_OK;
			}break;

		case 5:	//GETMTX
			{
			U_CHR as[61];
			ANY bp;
			XU_VAL t;

			if(!ocv->mat.isContinuous())
				{
				WRP_RET_ERR;					
				}

			UpdateMat(ocv);

			switch (ocv->mat.depth())
				{					
				case CV_8U:	t = L"U8"; break;
				case CV_8S:	t = L"I8"; break;
				case CV_16U:	t = L"U16"; break;
				case CV_16S:	t = L"I16"; break;
				case CV_32S:	t = L"I32"; break;
				case CV_32F:	t = L"F32"; break;
				case CV_64F:	t = L"F64"; break;
				}
				
			StrFormat(as, 60, L"BUF:CNK:%s:%d", (U_STRG) t, ocv->datSiz);
			bp= WRP_PTR_NEW((void*)ocv->dat, as);

			PTR_TO(BUF_MTX_DATA) pmd= new BUF_MTX_DATA;
			MtxFill(pmd,ocv,bp,t);

			WRP_SETRES_AS(res, L"BUF:MTX"); //Change the return
			res =(ANY)pmd;

			WRP_RET_OK;
			}break;				

		case 6:	//GETBUF
			{
			U_CHR as[61];
			XU_VAL t;

			if(!ocv->mat.isContinuous())
				{
				WRP_RET_ERR;					
				}

			UpdateMat(ocv);

			switch (ocv->mat.depth())
				{					
				case CV_8U:	t = L"U8"; break;
				case CV_8S:	t = L"I8"; break;
				case CV_16U:	t = L"U16"; break;
				case CV_16S:	t = L"I16"; break;
				case CV_32S:	t = L"I32"; break;
				case CV_32F:	t = L"F32"; break;
				case CV_64F:	t = L"F64"; break;
				}
				
			StrFormat(as, 60, L"BUF:CNK:%s:%d", (U_STRG)t, ocv->datSiz);

			WRP_SETRES_AS(res,as);  //Change the return
			res=(ANY)ocv->mat.data;			

			WRP_RET_OK;
			}break;				

		}
	WRP_RET_ERR;
	}

WRP_FUNC(OP, "Operation on MAT ")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, M1, mat 1);
	WRP_DCLPAR(U_STRG, OP, operator);
	WRP_DCLPAR(U_STRG, M2, mat 2);

	WRP_DCLRES_AS(RES, L"MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------
	double ALPHA;	

	if(_parNum_<2)
		{				
		WRP_RET_ERR;
		}	 

	int OPR=StrSelect(OP, L"+ SUM, - SUB, * MUL, / DIV, > GT, >= GE, < LT, <= LE, AND, OR, XOR, MIN, MAX, CROSS, DOT, ABS, INV", true);

	if (!OPR)
		{
		WRP_RET_ERR;		
		}

	PTR_TO(OCV_MAT)o1 = (OCV_MAT*)GET_OCV_PTR(M1, L"MAT");

	if (!o1 )
		{
		WRP_RET_ERR;
		}
	
	cv::Mat m;	
	cv::Mat m1 = o1->mat;
	cv::Mat m2;
	

	if(OPR < 16)
		{		
		PTR_TO(OCV_MAT)o2 = (OCV_MAT*)GET_OCV_PTR(M2, L"MAT");

		if (o2)
			{			
			m2 = o2->mat;
			}
		else {			
			ALPHA = XU_VAL_TMP(M2);
			switch (OPR)
				{
				case 3:
					{
					m = m1 * ALPHA;
					}break;

				case 4:
					{
					m = m1 / ALPHA;
					}break;
				// ---------
				case 5:
					{
					m = m1 > ALPHA;
					}break;

				case 6:
					{
					m = m1 >= ALPHA;
					}break;

				case 7:
					{
					m = m1 < ALPHA;
					}break;

				case 8:
					{
					m = m1 <= ALPHA;
					}break;

				// ---------
#ifdef min 
#undef min 
#endif
				case 12:
					{
					m = cv::min(m1, ALPHA);
					}break;
#ifdef max  
#undef max 
#endif
				case 13:
					{
					m = cv::max(m1, ALPHA);
					}break;

				// ---------
				default:
				WRP_RET_ERR;
				}

			RES = CreateMat(m);
			WRP_RET_OK;
			}
		}
	
	switch(OPR)
		{
		case 1:
			{
			m=m1 + m2;
			}break;

		case 2:
			{
			m=m1 - m2;
			}break;

		case 3:
			{
			m=m1 * m2;
			}break;

		case 4:
			{
			m=m1 / m2;
			}break;
		// ---------
		case 5:
			{
			m=m1 > m2;
			}break;

		case 6:
			{
			m=m1 >= m2;
			}break;

		case 7:
			{
			m=m1 < m2;
			}break;

		case 8:
			{
			m=m1 <= m2;
			}break;

		// ---------

		case 9:
			{
			m=m1 & m2;
			}break;

		case 10:
			{
			m=m1 | m2;
			}break;

		case 11:
			{
			m=m1 ^ m2;
			}break;

	// ---------
#ifdef min 
#undef min 
#endif
		case 12:
			{
			m=cv::min(m1,m2);
			}break;
#ifdef max  
#undef max 
#endif
		case 13:
			{
			m = cv::max(m1, m2);
			}break;

		// ---------

		case 14:
			{
			m=m1.cross(m2);
			}break;

		case 15:
			{
			m=m1.dot(m2);
			}break;

		// ---------
		// SINGLE Operand
		// ---------

		case 16:
			{
			m=cv::abs(m1);
			}break;

		case 17:
			{
			m=m1.inv();
			}break;

		}
		
	RES = CreateMat(m);
	WRP_RET_OK;
	}


WRP_FUNC(MAT_INF, "info of mat")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, PTR);
	WRP_DCLPAR(U_STRG, WHT,NULL);
	
	WRP_DCLRES(U_STRG, RES, resut);

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	if (!_parNum_)
		{	
		WRP_RET_ERR;
		}

	PTR_TO(OCV_MAT) ocv = (OCV_MAT*)GET_OCV_PTR(PTR, L"MAT");

	if (!ocv)WRP_RET_ERR;

	XU_VAL wht=WHT;
	XU_VAL res;
	
	if (wht == L"ALL")
		{		
		int ct=0;
		res= OCV_DATA_STRING;
		XU_VAL r=res;
		XU_VAL l;

		res <<= L"\r\n";

		while (~r)
			{
			l.SetS(r.GetUpToChr(L';'));
			if (~l == 0)
				{
				l.Move(r);
				}
			else {
				r.SetS(r.GetFromChr(L';'));
				}
			if(ct !=0)res <<= L";";
			else ct=1;
			res <<= GetOcvInf(ocv, l);			
			}
		RES=res.Reset();
		WRP_RET_OK;
		}

	RES= GetOcvInf(ocv, WHT);
	WRP_RET_OK;
	}

//------------------------------------------------------------------

WRP_FUNC(IMREAD, "Read an imagin")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, IMN);
	WRP_DCLPAR_DEF(U_STRG, FLG,NULL);
	
	WRP_DCLRES_AS(RES, L"MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	XU_VAL imn=IMN;
	XU_VAL flg=FLG;

	if (~imn==0)
		{
		WRP_RET_ERR;
		}

	PTR_TO(A_CHR)an = StrUtoA(IMN);
	cv::String n = an;
	delete an;

	if(~flg)
		flg.SetS(EnumDecode(flg, L"UNCHANGED= -1, GRAYSCALE = 0, COLOR = 1, ANYDEPTH = 2, ANYCOLOR = 4, LOAD_GDAL = 8, REDUCED_GRAYSCALE_2 = 16, REDUCED_COLOR_2 = 17, REDUCED_GRAYSCALE_4 = 32, REDUCED_COLOR_4 = 33, REDUCED_GRAYSCALE_8 = 64, REDUCED_COLOR_8 = 65,	IGNORE_ORIENTATION = 128"));
	else flg=-1;

	cv::Mat img = cv::imread(n, int(flg));
	if (img.empty())
		{	
		RES=NULL;
		WRP_RET_OK;
		}

	RES=CreateMat(img);
	WRP_RET_OK;
	}

WRP_FUNC(IMWRITE, "Write an imagin")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, PTR);
	WRP_DCLPAR(U_STRG, IMN);
	WRP_DCLPAR_DEF(U_STRG, FLG,NULL);
	
	WRP_DCLRES(ANY, RES);

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	XU_VAL imn=IMN;
	XU_VAL flg=FLG;

	cv::Mat d;
	flg=-1;

	if(_parNum_<2 || ~imn==0 )
		{		
		WRP_RET_ERR;
		}	 

	PTR_TO(OCV_MAT)ocv = (OCV_MAT*) GET_OCV_PTR(PTR, L"MAT");

	if (!ocv || ocv->mat.empty())
		{
		WRP_RET_ERR;
		}

	PTR_TO(A_CHR)an = StrUtoA(IMN);
	cv::String n = an;
	delete an;	

	switch(StrSelect(flg,L"BGR2RGB,BGR2RGBA",true))
		{
		case 0:	
			{
			try {
				cv::imwrite(n, ocv->mat); 
				RES=PTR;				
				}
			catch(...)
				{
				WRP_RET_ERR;
				}			
			}WRP_RET_OK;;

		case 1:	
			{
			cv::cvtColor(ocv->mat, d, cv::COLOR_BGR2RGB);
			}break;

		case 2:	
			{
			cv::cvtColor(ocv->mat, d, cv::COLOR_BGR2RGBA);
			}break;				
		}	
	
	try
		{
		cv::imwrite(n, d);
		RES = PTR;
		}
	catch (const std::exception&)
		{
		WRP_RET_ERR;
		}
	WRP_RET_OK;
	}

//------------------------------------------------------------------

WRP_FUNC(VCP, "Create Video Capture ")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, wht, Image source name);
	WRP_DCLPAR_DEF(int, api,0);
		
	WRP_DCLRES_AS(RES, L"VCP");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------
	
	RES = CreateVcp(wht, int(api));

	if (RES)
		{
		WRP_RET_OK;
		}

	WRP_RET_ERR;
	}


WRP_FUNC(VCP_RD, "Read from Video Capture ")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, PTR, Video capture PTR);	
	WRP_DCLPAR_DEF(ANY,MAT,NULL,"Already existing mat");
			
	WRP_DCLRES_AS(RES, L"MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	if(_parNum_<1)
		{					
		WRP_RET_ERR;
		}	 
	
	PTR_TO(OCV_VCP)ocv= (OCV_VCP*) GET_OCV_PTR(PTR, L"VCP");
				
	if (!ocv)
		{
		WRP_RET_ERR;
		}
		
	PTR_TO(OCV_MAT)mat = (OCV_MAT*)GET_OCV_PTR(MAT, L"MAT");	

	try {
		if(!mat)
			{
			cv::Mat m;
			ocv->vcp >> m;

			if (m.empty())
				{
				WRP_RET_ERR;
				}

			RES = CreateMat(m);		

			WRP_RET_OK;
			}
		else {
			ocv->vcp >> mat->mat;

			UpdateMat(mat);			

			WRP_SETRES_AS(RES, NULL);
			RES = MAT;

			WRP_RET_OK;
			}
		}	

	catch (...)
		{
		WRP_RET_ERR;
		}

	WRP_RET_ERR;	
	}

//------------------------------------------------------------------

WRP_FUNC(VWR, "Create Video Write ")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, wht, video name);
	WRP_DCLPAR(U_STRG, fcc, FCC p.e.�MJPG �PIM1);
	WRP_DCLPAR(F32, fps, frame  per second);
	WRP_DCLPAR(int, szx, size x);
	WRP_DCLPAR(int, szy, size y);
			
	WRP_DCLRES_AS(RES, L"VWR");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	if(_parNum_<5)
		{				
		WRP_RET_ERR;
		}	 

	RES = CreateVwr(wht, fcc, fps, szx, szy);

	if (RES)
		{
		WRP_RET_OK;
		}

	WRP_RET_ERR;
	}

WRP_FUNC(VWR_WR, "Write on Video Write ")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, ptr, VCP );
	WRP_DCLPAR(ANY, mat, MAT);
	
	WRP_DCLRES(ANY, RES, resut);

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	if(_parNum_<2)
		{				
		WRP_RET_ERR;
		}	 

	PTR_TO(OCV_VWR)vwr = (OCV_VWR*)GET_OCV_PTR(ptr, L"VWR");

	PTR_TO(OCV_MAT)ocv = (OCV_MAT*)GET_OCV_PTR(mat, L"MAT");

	if (!vwr || !ocv)
		{
		WRP_RET_ERR;
		}

	try
		{
		vwr->vwr.write(ocv->mat);
		}
	catch (const std::exception& )
		{
		WRP_RET_ERR;
		} 

	RES=ptr;
	WRP_RET_OK;
	}

//------------------------------------------------------------------

WRP_FUNC(BKS, "create a Back ground subtractor")
	{
	WRP_DCLBEG;
	
	WRP_DCLPAR_DEF(U_STRG, TYP,NULL, Type of subtractor);
	WRP_DCLPAR_DEF(U_STRG, SENS, NULL, Soglia flt);
	WRP_DCLPAR_DEF(U_STRG, SHD, NULL, shadow: �FALSE, �true);

	WRP_DCLRES_AS(RES, L"BKS");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	
	XU_VAL typ=TYP;
	XU_VAL sens=SENS;	
	XU_VAL shd=SHD;

	PTR_TO(OCV_BKS) sub=NULL;
	
	if(shd==L"TRUE")shd=0;
	else shd=1;

	int hst=1000;

	switch(StrSelect(typ,L"MOG2,KNN",true))
		{
		case 0:
		case 1:	
			{
			if(~sens==0)sens=16.0;
			sub=new OCV_BKS;
			sub->pBackSub = cv::createBackgroundSubtractorMOG2(hst,(double) sens,(int)shd);
			}break;

		case 2:	
			{
			if (~sens == 0)sens = 400;
			sub = new OCV_BKS;
			sub->pBackSub = cv::createBackgroundSubtractorKNN(hst, (double)sens, (int)shd);
			}break;
		}
		
	if(sub)
		{			
		RES = sub;
		WRP_RET_OK;
		}		

	WRP_RET_ERR;
	}

WRP_FUNC(BKSUPD, "Update BackGround Subtractor")
{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, BKS, PTR bks);
	WRP_DCLPAR(ANY, BKG, Bkg mat);
	WRP_DCLPAR_DEF(U_STRG, LRT, NULL, learn rate);
	WRP_DCLPAR_DEF(U_STRG, rqs, NULL, �PTR, �FRG, �MSK);
	
	WRP_DCLRES_AS(RES, L"MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	

	PTR_TO(OCV_BKS) sub=(OCV_BKS*) GET_OCV_PTR(BKS,L"BKS");

	if(!sub)	
		{		
		WRP_RET_ERR;
		}

	PTR_TO(OCV_MAT) ocvB = (OCV_MAT*)GET_OCV_PTR(BKG, L"MAT");
	
	if (ocvB)
		{
		cv::Mat d;
		cv::Mat fgMask;
	
		XU_VAL lrt = LRT;

		if (~lrt == 0)
			{
			lrt = -1.0;
			}

		WRP_PTR_LCKS(BKS);
		sub->pBackSub->apply(ocvB->mat, fgMask,lrt);
		WRP_PTR_LCKR(BKS);

		switch(StrSelect(rqs,L"MSK,FRG", true))
			{
			default:
			case 1:
				{
				RES = CreateMat(fgMask);
				}break;

			case 2:
				{
				ocvB->mat.copyTo(d, fgMask);
				RES = CreateMat(d);
				}break;

			}		
		if (RES)
			{
			WRP_RET_OK;
			}
		}

	WRP_RET_ERR;
	}

//------------------------------------------------------------------

WRP_FUNC(BKGRMV, "Subtract the background")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, FRG, Foreground MAT);
	WRP_DCLPAR(ANY, BKG, Background MAT or SUBtractor);

	WRP_DCLPAR_DEF(U_STRG, rqs, NULL, �PTR, �FRG, �MSK);

	WRP_DCLPAR_DEF(U_STRG, TYP, NULL, Type of subtractor);
	WRP_DCLPAR_DEF(U_STRG, SENS, NULL, Soglia flt);
	WRP_DCLPAR_DEF(U_STRG, SHD, NULL, shadow: �FALSE, �true);

	WRP_DCLPAR_DEF(ANY, nbk, NULL, new back ground);

	WRP_DCLRES_AS(RES, L"MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	
	XU_VAL typ = TYP;
	XU_VAL sens = SENS;
	XU_VAL shd = SHD;		

	PTR_TO(OCV_MAT) ocvF;
	PTR_TO(OCV_MAT) ocvB;
	PTR_TO(OCV_MAT) ocvN;
		
	cv::Mat fgMask;
	
	if(_parNum_<2 )
		{	
		WRP_RET_ERR;
		}	

	ocvF=(OCV_MAT*)GET_OCV_PTR(FRG, L"MAT");
		
	if (!ocvF)
		{
		WRP_RET_ERR;
		}

	ocvB = (OCV_MAT*)GET_OCV_PTR(BKG, L"MAT");

	if (!ocvB)
		{
		PTR_TO(OCV_BKS) sub= (OCV_BKS*)GET_OCV_PTR(BKG, L"BKS");
		
		if(!sub)
			{
			WRP_RET_ERR;
			}		
		
		WRP_PTR_LCKS(BKS);
		sub->pBackSub->apply(ocvF->mat, fgMask,0);
		WRP_PTR_LCKR(BKS);
		}
	else {
		if(ocvF->cols != ocvB->cols || ocvF->rows != ocvB->rows || ocvF->eTyp != ocvB->eTyp || ocvF->cTyp != ocvB->cTyp)
			{
			WRP_RET_ERR;
			}

		if (shd == L"TRUE")shd = 0;
		else shd = 1;
		int hst = 500;

		cv::Ptr<cv::BackgroundSubtractor> pBackSub;
					
		switch(StrSelect(typ,L"MOG2,KNN",true))
			{
			case 0:
			case 1:	{
					if (~sens == 0)sens = 16.0;
					pBackSub = cv::createBackgroundSubtractorMOG2(hst,(double) sens,(int)shd);
					}break;

			case 2:	{
					if (~sens == 0)sens = 400.0;
					pBackSub = cv::createBackgroundSubtractorKNN(hst, (double)sens, (int)shd);
					}break;
			}

		pBackSub->apply(ocvB->mat, fgMask);
		pBackSub->apply(ocvF->mat, fgMask, 0);
		}

	switch(StrSelect(rqs,L"MSK,FRG",true))
		{
		case 0:
		case	1:	
			{
			RES = CreateMat(fgMask);
			}break;

		case	2:
			{
			cv::Mat nfg;
			ocvN = (OCV_MAT*)GET_OCV_PTR(nbk, L"MAT");
			
			if(ocvN)
				{
				nfg=ocvN->mat.clone();
				}
				
			ocvF->mat.copyTo(nfg, fgMask);
			RES = CreateMat(nfg);
			}break;
		}

	WRP_RET_OK;
	}

//------------------------------------------------------------------

WRP_FUNC(QRC, "Detect Qr code")
	{
	WRP_DCLBEG;
	
	WRP_DCLPAR_DEF(ANY, IMG,NULL, Mat);
	WRP_DCLPAR_DEF(U_STRG, WHT, NULL, "�DETECTDECODE, �DETECT, �DECODE");
	
	WRP_DCLRES(U_STRG, RES, resut);

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	XU_VAL ptrimg, wht=L"DETECTDECODE",  rs, zm;
	PTR_TO(A_CHR) r;
	
	if(_parNum_<1 )
		{		
		WRP_RET_ERR;
		}

	PTR_TO(OCV_MAT) ocv=(OCV_MAT*)GET_OCV_PTR(IMG, L"MAT");
		
	if (!ocv)
		{
		WRP_RET_ERR;
		}
		
	cv::Mat m = ocv->mat ;
				
	if(m.empty())
		{
		WRP_RET_ERR;
		}
		
	cv::QRCodeDetector qrd;
	std::string ss;

	cv::Mat  bbox, rectified;  
	int f;
	
	switch(StrSelect(wht,L"DETECTDECODE,DETECT,DECODE",true))
		{
		case 0:
		case 1:	
			{
			try{
				f = qrd.detect(m,bbox);

				if(f)
					{			
					ss = qrd.detectAndDecode(m, bbox, rectified);
					r = (A_CHR*)ss.c_str();
					RES=StrUTFtoU(r);
					}
				}
			catch(...){ WRP_RET_ERR;}
			}WRP_RET_OK;
		}

	WRP_RET_ERR;
	}

//------------------------------------------------------------------

WRP_FUNC(CCL, "Cascade Classifier")
	{
	WRP_DCLBEG;
	
	WRP_DCLPAR(U_STRG, xml,"xml file ");	
	
	WRP_DCLRES_AS(RES, L"CCL", PTR);

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	
	if(_parNum_<1 )
		{		
		WRP_RET_ERR;
		}

	PTR_TO(A_CHR)x=StrUtoA(xml);

	if(!x)WRP_RET_ERR;

	PTR_TO(OCV_CCL)ccl=new OCV_CCL;

	try {
		if (ccl->ccl.load(x))
			{
			delete x;
			RES = ccl;
			WRP_RET_OK;
			}		
		RES=NULL;
		delete ccl;
		delete x;		
		}
	catch (...)
		{
		RES = NULL;
		delete ccl;
		delete x;
		}

	WRP_RET_ERR;
	}


WRP_FUNC(CCL_DTC, "Cascade Classifier DETECT")
	{
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, PTR, "CCL PTR ");
	WRP_DCLPAR(ANY, MAT, "mat ");
	WRP_DCLPAR_DEF(F32, SCL, 1.1, "Parameter specifying how much the image size is reduced at each image scale ");
	WRP_DCLPAR_DEF(int, minNeib, 3, "Parameter specifying how many neighbors each candidate rectangle should have	to retain it ");
	WRP_DCLPAR_DEF(U_STRG, MinSz,NULL, "w;h");
	WRP_DCLPAR_DEF(U_STRG, MaxSz, NULL, "w;h");

	WRP_DCLRES_AS( RES, L"BUF:MTX", PTR);

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	
	if(_parNum_<2 )
		{		
		WRP_RET_ERR;
		}

	PTR_TO(OCV_CCL)ccl= (OCV_CCL*)GET_OCV_PTR(PTR,L"CCL");
	PTR_TO(OCV_MAT)mat = (OCV_MAT*)GET_OCV_PTR(MAT, L"MAT");

	if (!ccl || !mat)
		{
		WRP_RET_ERR;
		}

	std::vector<cv::Rect> obj;

	try	{
		XU_VAL l,r;
		cv::Size minSz(0,0);
		cv::Size maxSz(0,0);

		if (MinSz)
			{
			r=MinSz;
			l.SetS(r.GetUpToChr(L';'));
			r.SetS(r.GetFromChr(L';'));
			minSz.width=(int)l;
			minSz.height = (int)r;
			}

		if (MaxSz)
			{
			r=MaxSz;
			l.SetS(r.GetUpToChr(L';'));
			r.SetS(r.GetFromChr(L';'));
			maxSz.width=(int)l;
			maxSz.height = (int)r;
			}

		cv::Mat gray;

		if(mat->eTyp != CV_8UC1 && mat->eTyp != CV_8SC1)
			{
			cv::cvtColor(mat->mat, gray, cv::COLOR_BGR2GRAY);
			}
		else {
			gray=mat->mat;
			}

		ccl->ccl.detectMultiScale(gray, obj, SCL, minNeib, 0,minSz, maxSz);
		}
	catch (const std::exception&)
		{
		WRP_RET_ERR;
		} 

	if (!obj.size())
		{
		RES=NULL;
		WRP_RET_OK;
		}

	int siz= obj.size()*4*sizeof(I32);
	PTR_TO(I32) buf=new I32[siz];
	PTR_TO(BUF_MTX_DATA) mtx=new BUF_MTX_DATA;

	XU_VAL as=L"BUF:BUF::";
	XU_VAL asp=siz;
	as <<= asp;

	mtx->esz=sizeof(I32);
	mtx->ten= obj.size()*4;
	mtx->msz=siz;
	mtx->mnd=2;
	mtx->dim=new unsigned[2]; mtx->dim[0]= obj.size();mtx->dim[1]=4;
	mtx->typ=L"I32";		
	mtx->pkp=WRP_PTR_NEW(buf,as);

	int ct=0;
	for(unsigned i=0; i<obj.size(); i++)
		{		
		buf[ct] = obj[i].x;ct++;
		buf[ct] = obj[i].y;ct++;
		buf[ct] = obj[i].x + obj[i].width;ct++;
		buf[ct] = obj[i].y + obj[i].height;ct++;
		}

	RES=mtx;

	WRP_RET_OK;
	}

//------------------------------------------------------------------
WRP_FUNC(DRW, "Draw")
	{
	WRP_DCLBEG;
	
	WRP_DCLPAR(ANY, PTR,"PTR to Mat ");	
	WRP_DCLPAR(U_STRG, OP, "Operation ");
	WRP_DCLPAR(ANY, DAT, "Data ");
	WRP_DCLPAR(U32, CLR, "Color 0xBBGGRRaa");
	WRP_DCLPAR_DEF(int, thickness, 1, "thickness ");
	WRP_DCLPAR_DEF(U_STRG, LINE, NULL, "Line type ");

	WRP_DCLRES(ANY,RES, L"PTR to MAT");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	
	if(_parNum_<2 )
		{		
		WRP_RET_ERR;
		}

	PTR_TO(OCV_MAT)mat = (OCV_MAT*)GET_OCV_PTR(PTR, L"MAT");

	if (!mat)
		{
		WRP_RET_ERR;
		}

	switch (StrSelect(OP, L"RECT"))
		{
		case 1: //RECT
			{
			if (XU_VAL_TMP((U_STRG)WRP_PTR(DAT, TAG)) != L"MTX")
				{
				XU_VAL t= (U_STRG)WRP_PTR(DAT, TAG);
				WRP_RET_ERR;
				}

			PTR_TO(BUF_MTX_DATA) mtx=(BUF_MTX_DATA* )WRP_PTR(DAT, PTR);

			if(!mtx)WRP_RET_ERR;

			int ty= StrSelect(mtx->typ, L"I32,U32");
			if(!ty)WRP_RET_ERR;

			if(mtx->mnd !=2)WRP_RET_ERR;

			int rn = mtx->dim[0];
			int cn = mtx->dim[1];

			cv::Scalar clr;

			clr[3]= CLR & 0xFF; CLR= CLR >> 8;
			clr[2] = CLR & 0xFF; CLR = CLR >> 8;
			clr[1] = CLR & 0xFF; CLR = CLR >> 8;
			clr[0] = CLR & 0xFF;

			int line=8;
			switch(StrSelect(LINE,L"FILLED,LINE_4,LINE_8,LINE_AA"))
				{
				case 1: line=-1;break;
				case 2: line =4; break;
				case 3: line = 8; break;
				case 4: line = 16; break;
				}

			I32(*pd)[4] = (I32(*)[4]) WRP_PTR(mtx->pkp, PTR);

			for (int r = 0; r < rn; r++)
				{
				cv::Point p1(pd[r][0], pd[r][1]);
				cv::Point p2(pd[r][2], pd[r][3]);
				try {
					cv::rectangle(mat->mat, p1, p2, clr, thickness, line);
					}
				catch(...)
					{
					WRP_RET_ERR;
					}				
				}
			}break;
		}
	RES=PTR;
	WRP_RET_OK;
	}

WRP_FUNC(SET, "Set parameter ")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, WHT, "parameter name");	
	WRP_DCLPAR_DEF(int,P1,0,"parameter 1");
	WRP_DCLPAR_DEF(int, P2, 0, "parameter 2");
			
	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	switch (StrSelect(WHT, L"nTHREAD"))
		{
		case 1:
			{
			cv::setNumThreads(P1);
			}break;
		}

	WRP_RET_OK;
	}
// ==========================================================================================
// Remeber to add a comma separated list of your function name (declared as WRP_FUNC)
// ==========================================================================================

WRP_INIT(VER, SET, MAT, OP, MAT_INF, IMREAD, IMWRITE, VCP, VCP_RD, VWR, VWR_WR, BKS, BKSUPD, BKGRMV, QRC, CCL, CCL_DTC, DRW);

//#pragma optimize( "", on )
// ==========================================================================================


