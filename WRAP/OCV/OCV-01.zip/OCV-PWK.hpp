#pragma once
/* ======================  ===================================================
		 XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
	 www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***				  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  OCV-PWK.hpp
   Version              :  01
   Date                 :  25/11/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI
   Workpakage           :  WRAP
   Task                 :  OCV
  ----------------------  ---------------------------------------------------
   License              :  APACHE 2
  ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   OpenCv support
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/


#include <opencv2/opencv.hpp>

#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

//************************************************************************************
// DO NOT Change this structures
//************************************************************************************
DEFINE(struct, Mat data payload defined in PWK as OCV_MAT_DAT - do Not Change)
OCV_MAT
	{		
	DATA(unsigned, datSiz, data size in byte);		// m->data size in byte
	DATA(PTR_TO(U8), dat, Data);					// m->data
	DATA(unsigned, chnSz, Channel size in byte);		// m->elemSize()
	DATA(unsigned, elmSz, Element size in byte);		// m->elemSize1()
	DATA(int, cTyp, Channel Type);				// m->type() like CV_16SC3 (enum)
	DATA(int, eTyp, Element Type);				// m->depth()
	DATA(int, tot, Total number of element);		// m->total() 
	DATA(int, dims, Dimension if >= 2);			// m->dims
	DATA(int, rows, -1 if dims > 2);				// m->rows
	DATA(int, cols, -1 if dims > 2);				// m->cols
	DATA(int, chn, Channel num);					// m->channels()

	DATA(XU_VAL, cTypS, Channel Type);				// m->type() like CV_16SC3 (enum)
	DATA(XU_VAL, eTypS, Element Type);				// m->depth() like CV_16S
	DATA(XU_VAL, winFmt, Format for windows);		//

	DATA(int, stp, step);						// m->step
	DATA(int, flg_cont, 1 = continuos);			// m->isContinuous()
	DATA(int, flg_sub, 1 = submtrix);				// m->isSubmatrix()

	//Should be at the end because does non exists in PWK
	DATA(cv::Mat, mat, The mat);
	};


void MtxFill(PTR_TO(BUF_MTX_DATA)mtx,PTR_TO(OCV_MAT)ocv, ANY buf, PTR_TO(U_CHR)ty);


//************************************************************************************
#define OCV_DATA_STRING L"COL;ROW;DATSIZ;TOTELM;CHN;CHNtyp;CHNsiz;ELMtyp;ELMsiz;FRMT"

PTR_TO(U_CHR) GetOcvInf(PTR_TO(OCV_MAT)ocv, PTR_TO(U_CHR)key);

DEFINE(struct, Video Capture )
OCV_VCP
	{	
	cv::VideoCapture vcp;
	DATA(int, sts,	"1=working 0=stop");
	D_BUILDER(OCV_VCP)()
		{
		sts=0;
		}
	};

DEFINE(struct, Video Writer  )
OCV_VWR
	{	
	cv::VideoWriter vwr;
	int szx;
	int szy;
	};

DEFINE(struct, Back ground subtractor)
OCV_BKS
	{
	cv::Ptr<cv::BackgroundSubtractor> pBackSub;

	D_BUILDER(OCV_BKS)()
		{
		pBackSub=NULL;
		}
	};

DEFINE(struct, Cascade classifier)
OCV_CCL
	{
	cv::CascadeClassifier ccl;
	};


PTR_TO(OCV_MAT) CreateMat(cv::Mat mat);
PTR_TO(OCV_VCP) CreateVcp(PTR_TO(U_CHR)s = NULL, int API = 0);
PTR_TO(OCV_VWR) CreateVwr(PTR_TO(U_CHR)s, PTR_TO(U_CHR)f4, double fps, int szx, int szy);


ANY UpdateMat(PTR_TO(OCV_MAT)ocv);

FUNCTION(PTR_TO(U_CHR), Giving a symbol defined in enum return the value)
EnumDecode(PTR_TO(U_CHR)v, PTR_TO(U_CHR)e);

FUNCTION(PTR_TO(U_CHR), Return the code of OCV color names)
CNVCLR_CODE(PTR_TO(U_CHR)p);

FUNCTION(PTR_TO(U_CHR), from the code of an OCV ELEMENT TYPE return the name)
OCV_MAT_ETYP(int t);

FUNCTION(int, from the name of an OCV ELEMENT TYPE return the code)
OCV_MAT_ETYP(PTR_TO(U_CHR) t);

FUNCTION(PTR_TO(U_CHR), from the code of an OCV CHANNEL TYPE return the name)
OCV_MAT_CTYP(int t);

FUNCTION(int, from the name of an OCV CHANNEL TYPE return the code)
OCV_MAT_CTYP(PTR_TO(U_CHR) t);

