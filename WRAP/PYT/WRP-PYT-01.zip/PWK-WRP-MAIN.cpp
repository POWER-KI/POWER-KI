/* ======================  ===================================================
		 XPLAB           Xplab s.a.s. - viale Sant Eufemia, 39
   Research in Automation                 25135 Brescia - Italy
	 www.xplab.net                       Tel +39 030 2350035
    *** RESERVED ***				  (C) 2020 XPLAB CAP
   ======================  ===================================================
   File name            :  PWK-WRP-MAIN.Cpp
   Version              :  01
   Date                 :  28/02/20
   Author               :  CAP
   ----------------------  ---------------------------------------------------
   Project              :  POWER-KI
   Workpakage           :  WRAP
   Task                 :  
  ----------------------  ---------------------------------------------------
   License              :  APACHE 2
  ======================  ===================================================

   ABSTRACT:
   ---------------------------------------------------------------------------
   USER code of the WRAP DLL
  ---------------------------------------------------------------------------

   REVISION HISTORY:
  ----------------------  ---------------------------------------------------
   01                     First version
  ----------------------  ---------------------------------------------------
*/


// ==========================================================================================
// PWK WRP
// ==========================================================================================

#include <process.h>

//#define Py_LIMITED_API 0x030A0000
#define PY_SSIZE_T_CLEAN

#include <Python.h>


#undef NONE
#undef NO
#undef MIN
#undef MAX

#include "PWK-WRP-CORE-01.hpp"

//-----------------------------------------------------------

NOTE("IN Properties\C/C++\Command Line:Additional Option -> add: /Zc:strictStrings- ")

//#pragma optimize( "", off ) //Disable Optimization

// =======================================================================
// Your Type Exposed to POWER-KI 
// =======================================================================


static int PWK_PYE_INIT=0;


//--------------
#define PYT_ENTER
#define PYT_LEAVE
/*

//--------------
#define PYT_ENTER \
PyGILState_STATE gstate;\
gstate = PyGILState_Ensure();

#define PYT_LEAVE \
PyGILState_Release(gstate);

//--------------

#define PYT_ENTER \
PyThreadState* _state= Py_NewInterpreter(); \
PyImport_ImportModule("pwk");

#define PYT_LEAVE \
Py_EndInterpreter(_state);

*/
//---------------------------------------

DEFINE(struct, "PWK PYT Module object")
PWK_PYT_MDL
	{
	PyObject* mdl;
	
	D_BUILDER(PWK_PYT_MDL)()
		{
		mdl=NULL;
		}

	D_DESTROYER(PWK_PYT_MDL)
		{
		if (Py_IsInitialized())
			{
			if(mdl) Py_XDECREF(mdl);
			}
		}
	};


PyObject* XUVtoPYO(XU_VAL &ls)
	{
	PyObject* p_val=NULL;
	F64		vf;
	U64		vu;
	I64		vi;

	if (!ls.IsNum())
		{
		Nospaces(ls);
		if (ls.Fst() == L'\"' && ls.Lst() == L'\"')
			{
			ls << 1;
			ls.Lst(0);
			}
		else {
			if (ls.Fst() == L'\'' && ls.Lst() == L'\'')
				{
				ls << 1;
				ls.Lst(0);
				}
			}

		p_val = Py_BuildValue("u", ls);	//Unicode
		}
	else {
		if (ls.IsFlt())
			{
			vf=ls;
			p_val = Py_BuildValue("d", vf); //Double
			}
		else {
			if (ls.IsNum())
				{
				vi=ls;
				p_val = Py_BuildValue("L",vi); //LONG
				}			
			}
		}
	return p_val;
	}

U_CHR* PYOtoXUV(PyObject* p_res)
	{
	XU_VAL v;
	U_CHR *	vs;
	F64		vf64;
	U64		vu64;
	I64		vi64;
	
	if(p_res == NULL) return NULL;
	
	if (PyLong_Check(p_res))
		{
		v=(I64)PyLong_AsLongLong(p_res);

		return v.Reset();
		}

	if (PyFloat_Check(p_res))
		{
		v = (F64)PyFloat_AsDouble(p_res);

		return v.Reset();
		}

	if (PyUnicode_Check(p_res))
		{
		v =(U_CHR*) _PyUnicode_AsUnicode(p_res);
		return v.Reset();
		}

	PyObject* repr = PyObject_Repr(p_res);
	v = (U_CHR*)_PyUnicode_AsUnicode(repr);	

	Py_XDECREF(repr);

	return v.Reset();
	}

//-----------------------------------------------------------

void PYT_ERR()
	{
	PyObject* ptype, * pvalue, * ptraceback;
	PyErr_Fetch(&ptype, &pvalue, &ptraceback);
	//pvalue contains error message
	//ptraceback contains stack snapshot and many other information
	//(see python traceback structure)
	PyObject* pstr = PyObject_Str(pvalue);
	//Get error message
	const char* pEM = PyUnicode_AsUTF8(pstr);
	if(pEM)
		{
		WRP_TRACE(StrUTFtoU((char*)pEM));
		delete pEM;	
		}		
	PyErr_Restore(ptype, pvalue, ptraceback);
	}



static PyObject* PWKMDL_EXEC(PyObject* self, PyObject* args)
	{
	U_CHR * cmd=NULL;
	PyObject* res=NULL;
	XU_VAL v;

	if(!PyArg_ParseTuple(args, "u", &cmd))
		return NULL;

	v.SetS((U_CHR*)WRP_PWK_EXEC(cmd));

	res=XUVtoPYO(v);

	return res;
	}

static PyObject* PWKMDLError;

static PyMethodDef PWKMDLMethods[] = 
	{    
    {"exc",  PWKMDL_EXEC, METH_VARARGS,"Execute PWK command."},    
    {NULL, NULL, 0, NULL}        /* Sentinel */
	};


static struct PyModuleDef PWKmodule = {
    PyModuleDef_HEAD_INIT,
    "pwk",	/* name of module */
    NULL,		/* module documentation, may be NULL */
    -1,		/* size of per-interpreter state of the module,
			  or -1 if the module keeps state in global variables. */
    PWKMDLMethods
};


PyMODINIT_FUNC
PyInit_pwk(void)
	{
	return PyModule_Create(&PWKmodule);	
	}

//-----------------------------------------------------------

static PyObject* PWK_MDL = NULL;


void PYT_INIT() //CALLED from DLL_MAIN
	{		
	if(!Py_IsInitialized())	
		{
		PyImport_AppendInittab("pwk", PyInit_pwk);
		Py_InitializeEx(0); // (0) = skips initialization registration of signal handlers		

		PWK_MDL = PyImport_ImportModule("pwk");			

		//ADD PWK Path --------------------------
		XU_VAL fp;
		PyObject* programPath;

		PyObject* sysPath = PySys_GetObject((char*)"path");

		fp.SetS((U_CHR*)WRP_PWK_EXEC(L"prgpth"));
		if (~fp)
			{
			programPath = Py_BuildValue("u", fp);
			PyList_Insert(sysPath, 0, programPath);
			Py_XDECREF(programPath);
			}

		fp.SetS((U_CHR*)WRP_PWK_EXEC(L"pkgpth"));
		if(~fp)
			{
			programPath = Py_BuildValue("u", fp);
			PyList_Insert(sysPath, 0, programPath);
			Py_XDECREF(programPath);
			}
		
		// ---------------------------------------
		PyErr_Clear();
		PWK_PYE_INIT = 1;

		//PyList_Append(sysPath, programPath);
		}
	
	}

void PYT_TERM()
	{		
	PyErr_Clear();

	return;
	if (Py_IsInitialized())
		{
		Py_XDECREF(PWK_MDL);

		Py_FinalizeEx();
		PWK_PYE_INIT = 0;
		}

	}
//-----------------------------------------------------------



// =======================================================================
// Your pointer destroyer .. 
// =======================================================================

WRP_DEL(PTR, TYP, PAY, Delete WRP pointer returned by PWK)
	{
	// PTR is void*
	// TYP is U_CHR *
	// PAY is ANY

	if(!StrCmp_I(TYP,L"MDL"))
		{
		delete (PWK_PYT_MDL*) PTR;
		return;
		}
	}

// =======================================================================
// your code .. 
// =======================================================================

WRP_FUNC(VER, "Return version number")
	{
	WRP_DCLBEG;

	WRP_DCLRES(U_STRG, ver, L"Version");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	XU_VAL v=L"1.0 :", vp;
	vp.SetS(StrAtoU((A_CHR*)Py_GetVersion()));

	v <<= vp;
	ver=v.Reset();

	WRP_RET_OK;
	}


WRP_FUNC(INIT, "Init PyThon  Environment")
	{
	WRP_DCLBEG;
	
	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	PYT_INIT();
		
	WRP_RET_OK;
	}

WRP_FUNC(TERM, "Terminate PyThon  Environment")
	{
	WRP_DCLBEG;


	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	PYT_TERM();

	WRP_RET_OK;
	}

static PyGILState_STATE gil;

WRP_FUNC(BEG, "Acquire GIL Global Interpreter Lock")
	{
	WRP_DCLBEG;
	
	WRP_DCLRES(ANY, res, "PyGILState_STATE");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	if (!PWK_PYE_INIT)
		{
		PYT_INIT();
		}

	//gil=PyGILState_Ensure();
	res= (ANY)PyGILState_Ensure();

	WRP_RET_OK;
	}

WRP_FUNC(END, "Release GIL Global Interpreter Lock")
	{
	WRP_DCLBEG;
	WRP_DCLPAR(ANY, par, "PyGILState_STATE");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------

	if (!PWK_PYE_INIT)
		{
		PYT_INIT();
		}

	PyGILState_STATE p = (PyGILState_STATE)(unsigned)par;
	PyGILState_Release(p);

	//PyGILState_Release(gil);

	WRP_RET_OK;
	}


WRP_FUNC(LOAD, "LOAD a module")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, mdl, "Module");
	WRP_DCLPAR_DEF(int, src, 0, "1= load with PIP");

	WRP_DCLRES_AS(res, L"MDL", "PTR To Module");
	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------
	PWK_PYT_MDL * pyt=NULL;
	PyObject* p_nam = NULL;	

	if( !PWK_PYE_INIT) 
		{
		PYT_INIT();
		}

	PYT_ENTER;
	try{		
		XU_VAL fp, fn,ex;
		fn=mdl;	
		if(StrChr(fn,L'\\'))
			{		
			fp.SetS(fn.GetFromChrRvs(L"\\"));
			fn.SetS( fn.GetUpToChrRvs(L"\\"));		

			fp <<= L"\\";
				
			PyObject* sysPath = PySys_GetObject((char*)"path");
			PyObject* programPath = Py_BuildValue("u", fp); 
		
			PyList_Insert(sysPath,0, programPath);

			//PyList_Append(sysPath, programPath);
			Py_XDECREF(programPath);						
			}

		if (StrChr(fn, L'.'))
			{
			ex.SetS(fn.GetUpToChrRvs(L'.'));
			if(ex == L"py")
				{
				fn.SetS(fn.GetUpToChr(L'.'));
				}
			}

		p_nam = Py_BuildValue("u", fn);	

		pyt=new PWK_PYT_MDL;
		pyt->mdl = PyImport_Import(p_nam);	

		if (!pyt->mdl && src != 0 && ~fp==0)
			{
			int r;
			XU_VAL t = L"WRP PYT - installing module with pip ";
			t <<= fn;
			t <<= L"...wait...";
			WRP_TRACE(t);
		
			t=L"pip.exe install "; t <<= fn;
		
			try
				{
				_wsystem(t);
				pyt->mdl = PyImport_Import(p_nam);
				}
			catch (...)
				{
				;
				}
			
			}


		if (!pyt->mdl)
			{
			XU_VAL t= L"WRP PYT - Module not found: ";
			t <<= mdl;
			WRP_TRACE(t);
			PYT_ERR();
			delete pyt;
			pyt=NULL;
			Py_XDECREF(p_nam);
		
			PyErr_Clear();
			PYT_LEAVE;
			WRP_RET_ERR;
			}
		
		Py_XDECREF(p_nam);
		res=pyt;	
		}
	catch (...)
		{
		PyErr_Clear();
		PYT_LEAVE;
		WRP_RET_ERR;
		}

	PYT_LEAVE;
	WRP_RET_OK;
	}

WRP_FUNC(CALL, "Ivoke a PyThon function from a module")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, mdl,"Module PTR");
	WRP_DCLPAR(U_STRG, fnc,"Function");
	WRP_DCLPAR_DEF(U_STRG, par,NULL,"parameter separated by separator");
	WRP_DCLPAR_DEF(U16, sep, L',', "Separator code");

	WRP_DCLRES(U_STRG, res, L"Result");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	int erf=0;
	A_CHR  *a_fnc=NULL;
	PyObject  *p_fnc=NULL, *p_par=NULL, *p_res=NULL, *p_val=NULL;

	if(mdl==NULL)WRP_RET_ERR;

	PWK_PYT_MDL* pyt = (PWK_PYT_MDL*)WRP_PTR(mdl, PTR);
	if (pyt == NULL || fnc==NULL )WRP_RET_ERR;

	int npar=0;
	U_CHR* ps=par;

	while (ps && VAL_OF(ps))
		{
		npar++;
		ps=StrChr(ps,sep);
		if(ps) ps++;
		}

	a_fnc=StrUtoA(fnc);

	PYT_ENTER;
	try {		
		if (pyt->mdl != NULL)
			{	
			p_fnc= PyObject_GetAttrString(pyt->mdl, a_fnc);		

			if (p_fnc && PyCallable_Check(p_fnc))
				{
				if(npar)
					{
					p_par=PyTuple_New(npar);
					npar=0;
				
					XU_VAL ls,rs;
					rs=par;
			
					while(StrChr(rs, sep))
						{
						ls.SetS(rs.GetUpToChr(sep));
						rs.SetS(rs.GetFromChr(sep));

						p_val=XUVtoPYO(ls);

						PyTuple_SetItem(p_par,npar,p_val);		
						npar++;
						}
	
					if (~rs)
						{
						p_val = XUVtoPYO(rs);
						PyTuple_SetItem(p_par, npar, p_val);				
						}				
					}

				p_res = PyObject_CallObject(p_fnc, p_par);

				if (!p_res)
					{
					PyErr_Clear();
					erf=1;
					}
				else {
					res= PYOtoXUV(p_res);			
					Py_XDECREF(p_res);
					}
				}
			else erf=1;
			}
		else erf=1;

		Py_XDECREF(p_fnc);
		Py_XDECREF(p_par);		
		}
	catch (...)
		{
		PyErr_Clear();
		erf=1;
		}

	PYT_LEAVE;
	if(a_fnc)delete a_fnc;
	
	if(erf)WRP_RET_ERR;

	WRP_RET_OK;
	}

WRP_FUNC(INF, "list of module names")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(ANY, mdl, "Module PTR");
	WRP_DCLRES(U_STRG, res, L"Result");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	

	PWK_PYT_MDL* pyt = (PWK_PYT_MDL*)WRP_PTR(mdl, PTR);

	if(pyt == NULL)WRP_RET_ERR;

	if (!PWK_PYE_INIT)
		{
		PYT_INIT();
		}

	PYT_ENTER;
	try	{		
		PyObject* p_res= PyObject_Dir(pyt->mdl);
	
		res = PYOtoXUV(p_res);
		Py_XDECREF(p_res);
		
		}
	catch (...)
		{
		PYT_LEAVE;
		res=NULL;
		WRP_RET_ERR;
		}

	PYT_LEAVE;
	WRP_RET_OK;
	}


WRP_FUNC(EVAL, "Evaluate a PyThon expression")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, cod, "PyThon Code");
	WRP_DCLRES(U_STRG, res, L"Result");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	int erf=0;

	if(!cod)WRP_RET_ERR;

	if( !PWK_PYE_INIT) 
		{
		PYT_INIT();
		}	

	PYT_ENTER;
	PTR_TO(A_CHR)a_cod=StrUtoUTF(cod);

	PyObject* p_res = NULL;	
	try {
		PyObject* gd=NULL;
		PyObject* main = PyImport_AddModule("__main__");
		if (main)
			{
			gd = PyModule_GetDict(main);
			
			PyObject* bi = PyImport_AddModule("__builtin__");
			if (bi)
				{
				PyObject* pd = PyModule_GetDict(bi);
				PyDict_Update(gd, pd);
				}

			PyObject* pwk = PyImport_AddModule("pwk");
			if(pwk)
				{
				PyObject* pd = PyModule_GetDict(pwk);
				PyDict_Update(gd, pd);
				}
			}

		//Py_eval_input
		//Py_file_input
		//Py_single_input

		p_res = PyRun_String(a_cod, Py_eval_input, gd, gd);
		}
	catch (...)
		{		
		WRP_TRACE(L"WRP PYT - EVAL ExCEPTION");		
		PYT_ERR();
		PyErr_Clear();
		} 

	if(a_cod)delete a_cod;

	if (p_res == NULL)
		{
		if(PyErr_Occurred())
			{
			WRP_TRACE(L"WRP PYT - EVAL ERR");
			PYT_ERR();
			PyErr_Clear();
			erf=1;
			}
		}
	else {
		res = PYOtoXUV(p_res);
		}

	Py_XDECREF(p_res);
	PYT_LEAVE;

	if(erf) WRP_RET_ERR;
	WRP_RET_OK;
	}


WRP_FUNC(EXEC, "Execute a PyThon expression")
	{
	WRP_DCLBEG;

	WRP_DCLPAR(U_STRG, cod, "PyThon Code");
	WRP_DCLRES(U_STRG, res, L"Result");

	WRP_DCLEND;

	//-----------------------------
	//now your code !! never before
	//-----------------------------	
	int erf=0;

	if(!cod)WRP_RET_ERR;

	if( !PWK_PYE_INIT) 
		{
		PYT_INIT();
		}
	
	PYT_ENTER;
	PTR_TO(A_CHR)a_cod = StrUtoUTF(cod);
	
	PyObject* p_res = NULL;
	
	try {
		PyObject* gd=NULL;
		PyObject* main = PyImport_AddModule("__main__");
		if (main)
			{
			gd = PyModule_GetDict(main);
		
			PyObject* bi = PyImport_AddModule("__builtin__");
			if (bi)
				{
				PyObject* pd = PyModule_GetDict(bi);
				PyDict_Update(gd, pd);
				}


			PyObject* pwk = PyImport_AddModule("pwk");
			if(pwk)
				{
				PyObject* pd = PyModule_GetDict(pwk);
				PyDict_Update(gd, pd);
				}
			}

		//Py_eval_input
		//Py_file_input
		//Py_single_input
	
		p_res = PyRun_String(a_cod, Py_file_input, gd, gd);
		}
	catch (...)
		{
		WRP_TRACE(L"WRP PYT - EXEC ExCEPTION");
		PYT_ERR();
		PyErr_Clear();		
		} 

	
	if(a_cod)delete a_cod;

	if (p_res == NULL)
		{
		if(PyErr_Occurred())
			{
			WRP_TRACE(L"WRP PYT - EXEC ERR");
			PYT_ERR();
			PyErr_Clear();
			erf = 1;			
			}
		}
	else {
		res = PYOtoXUV(p_res);
		}

	Py_XDECREF(p_res);	

	PYT_LEAVE;

	if(erf) WRP_RET_ERR;
	WRP_RET_OK;	
	}




// ==========================================================================================
// Remember to add a comma separated list of your function name (declared as WRP_FUNC)
// ==========================================================================================

WRP_INIT(VER,LOAD,CALL,EVAL,EXEC,INF,INIT,TERM, BEG, END);

//#pragma optimize( "", on )
// ==========================================================================================


